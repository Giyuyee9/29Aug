// script.js - Client side Controller Script 
var actasadmin=false;  // Default act as admin should always be false.
var restWebserviceHost;
var currentlyLoginUser;
var restWebserviceHostlookup;
var restWebserviceHostapp;
var restWebserviceHostrep;
var isTableauSecure;
var restAppSvc;
var fcipUIHost;
var refresh;

var fcipApp  = angular.module('fcipApp', [ 'ngRoute' ]);


var wgserver = 'tbwtpc04advvg.tdc.vzwcorp.com';
var uVZID ="v762648"; 
var viz;
var tabkeyApi="http://eu9sacexn02.ebiz.verizon.com:7002/analyticsTableauKey/TableauKey"; 
var sitename="CPM"; 

fcipApp.config(function($routeProvider) {
	
	$routeProvider
	.when('/', {
		templateUrl : 'pages/home.html'
	})

	.when('/tool', {
		templateUrl : 'pages/tools.html'
	})
	
	.when('/ar', {
		template :'<iframe id="ifrSpend" width="100%" style="overflow: hidden; width: 100%;" src="https://fcipqliktest.ebiz.verizon.com/extensions/spenddashboard/spenddashboard.html" onload="resizeIframe></iframe>' 
	})
	
	.when('/dashboardList/:menu/:project', {	
		templateURI : 'https://fcipwidgetservice-dev.cfappstdcnpz1.ebiz.verizon.com/FCIPWidget/getContentByKey?key=FCIP_NGROUTE_DASHBOARDLIST',
		controllerURI : 'https://fcipwidgetservice-dev.cfappstdcnpz1.ebiz.verizon.com/FCIPWidget/getContentByKey?key=FCIP_NGROUTE_CTRLR_DASHBOARDLIST',
		controllerName : 'dashboardListController',		
		template: '',
		resolve : {
			templateLoad : function($http,$q,$route,$routeParams) {						
				var defer = $q.defer();
				//setRouteTemplate($http,defer,$route,$route.current.$$route.templateURI);				
				$route.current.$$route.template = $http.get($route.current.$$route.templateURI).then(function(response){
							 return '<div class="container dashboardListController" ng-app="fcipApp" ng-controller="dashboardListController">' + response.data + '</div>';
							defer.resolve();
						});
				defer.promise;		
			}
		}	
	})
	
	.when('/tableau/:menu/:site/:viewname', {
		templateUrl : 'pages/tableau.html',
		controller : 'tableauController'
	})

	
	
	
	

});

function resizeIframe(obj){	
	/*console.log(obj.contentWindow.parent.document.body.scrollHeight);
    var newheight=obj.contentWindow.parent.document.body.scrollHeight;
    obj.style.height=newheight+'px';
	*/
	iFrameResize({
		log                     : true,                  // Enable console logging
		enablePublicMethods     : true,                  // Enable methods within iframe hosted page
		resizedCallback         : function(messageData){ // Callback fn when resize is received
			$('p#callback').html(
				'<b>Frame ID:</b> '    + messageData.iframe.id +
				' <b>Height:</b> '     + messageData.height +
				' <b>Width:</b> '      + messageData.width + 
				' <b>Event type:</b> ' + messageData.type
			);
		},
		messageCallback         : function(messageData){ // Callback fn when message is received
			$('p#callback').html(
				'<b>Frame ID:</b> '    + messageData.iframe.id +
				' <b>Message:</b> '    + messageData.message
			);
			alert(messageData.message);
		},
		closedCallback         : function(id){ // Callback fn when iFrame is closed
			$('p#callback').html(
				'<b>IFrame (</b>'    + id +
				'<b>) removed from page.</b>'
			);
		}
	});

}
  
function setRouteTemplate(http,q,route,URL){	
	http({
		method: 'GET',
		url: URL
	}).success(function(response, status, headers, config){				
		route.current.$$route.template = '<div class="container dashboardListController" ng-app="fcipApp" ng-controller="dashboardListController">' + response.data + '</div>';		
		q.resolve(response, status, headers, config);				
	});	
	return q.promise;	
}



function initViz(tabURL) {
	var containerDiv = document.getElementById("vizContainer");
	var    url = tabURL;
	var    options = {
			hideTabs: true,
			onFirstInteractive: function () {
				console.log("Run this code when the viz has finished loading.");
			}
		};
	
	var viz = new tableau.Viz(containerDiv, url, options); 
}

function ThumbnailViewModel(workbook,token,http) {		
	
	var self = this;
	self.ModelName = "Thumbnails";			
	self.WorkBookId = workbook.workbookId;
	self.WorkBookName = workbook.workbookName;
	self.ProjectId = workbook.projectId;
	self.ProjectName = workbook.projectName;
	self.SRC = getBase64Img(workbook.workbookId,workbook.url,token,http);	
	self.ViewURL = getViewURL(workbook.workbookId,workbook.workbookName,http);	
}

fcipApp.controller('dynamicController',function($scope,$rootScope,$routeParams, $http) {	
	$http.get('https://fcipwidgetservice-dev.cfappstdcnpz1.ebiz.verizon.com/FCIPWidget/getContentByKey?key=FCIP_NGROUTE_DASHBOARDLIST').then(function(payload){ $scope.template = payload });	
});	



function loadTemplate(http,URL){		
	http({
			method: 'GET',
			url: URL
		}).success(function(response){				
			return response;						
		}).error(function(response){						
			
		});	
	}

fcipApp.controller('dashboardListController',function($scope,$rootScope,$routeParams, $http) {
	alert('dashboardListController');
	$rootScope.navpagname = "Home";
	$rootScope.navpagnameURL = "#";
	$rootScope.pagenameURL = "#/dashboardList/" + $routeParams.menu + "/" + $routeParams.project;	
	$rootScope.pagename = $routeParams.menu;	
	$scope.project = $routeParams.project;	
	//var siteID = ($routeParams.sitename != "FinanceCIP" ? $routeParams.sitename : "");
	if($rootScope.project !=="null"){
		$scope.progressLbl=false;
		$http({
			method: 'POST',
			url: document.getElementById('tableauSvc').value+'Tableau/getThumbnail',
			headers: {'Content-Type':'application/json'},
			data: {"userName" : uVZID} 
		}).success(function(response){	
			var respData = response;						
			var thumbNailList=[];			
			for (var i=0;i<	response.workbookThumbnail.length;i++) {													
				var wb = respData.workbookThumbnail[i];				
				var tb = new ThumbnailViewModel(wb,respData.token,$http);
				thumbNailList.push(tb);				
			}			
			$scope.thumbNails = thumbNailList;				
			$scope.progressLbl=false;
			/*for (var i=0;i<	respData.workbookThumbnail.length;i++) {				
				getBase64Img(respData.workbookThumbnail[i].workbookId,respData.workbookThumbnail[i].url,respData.token);
			}*/
			
		}).error(function(response){
			$scope.progressLbl=false;
		});
	}
	
});//End main controller


fcipApp.controller('dashboardListControllerNew',function($scope,$rootScope,$routeParams, $http,$sce,$compile) {			
	/*var shtml = loadTemplate($http,'https://fcipwidgetservice-dev.cfappstdcnpz1.ebiz.verizon.com/FCIPWidget/getContentByKey?key=FCIP_NGROUTE_DASHBOARDLIST');		
	$scope.template =  $sce.trustAsHtml(shtml);
	*/
		$http({
			method: 'GET',
			url: 'https://fcipwidgetservice-dev.cfappstdcnpz1.ebiz.verizon.com/FCIPWidget/getContentByKey?key=FCIP_NGROUTE_DASHBOARDLIST'
		}).success(function(response){	
			var shtml = response;			
			jQuery('.dashboardListController').html(shtml);
			var element = jQuery('.dashboardListController');
			$compile(element.contents())($scope);
			$scope.template =  response;						
			$rootScope.navpagname = "Home";
			$rootScope.navpagnameURL = "#";
			$rootScope.pagenameURL = "#/dashboardList/" + $routeParams.menu + "/" + $routeParams.project;	
			$rootScope.pagename = $routeParams.menu;	
			$scope.project = $routeParams.project;	
			//var siteID = ($routeParams.sitename != "FinanceCIP" ? $routeParams.sitename : "");
			if($rootScope.project !=="null"){
				$scope.progressLbl=false;
				$http({
					method: 'POST',
					url: document.getElementById('tableauSvc').value+'Tableau/getThumbnail',
					headers: {'Content-Type':'application/json'},
					data: {"userName" : uVZID} 
				}).success(function(response){	
					var respData = response;						
					var thumbNailList=[];			
					for (var i=0;i<	response.workbookThumbnail.length;i++) {													
						var wb = respData.workbookThumbnail[i];				
						var tb = new ThumbnailViewModel(wb,respData.token,$http);
						thumbNailList.push(tb);				
					}			
					$scope.thumbNails = thumbNailList;				
					$scope.progressLbl=false;
					/*for (var i=0;i<	respData.workbookThumbnail.length;i++) {				
						getBase64Img(respData.workbookThumbnail[i].workbookId,respData.workbookThumbnail[i].url,respData.token);
					}*/
					
				}).error(function(response){
					$scope.progressLbl=false;
				});
			}			
		}).error(function(response){						
			
		});	
	}
	/*$http.get('https://fcipwidgetservice-dev.cfappstdcnpz1.ebiz.verizon.com/FCIPWidget/getContentByKey?key=FCIP_NGROUTE_DASHBOARDLIST').then(function(payload){ return payload });	*/	
	
	
);//End main controller

	function getViewURL(workbookId, workbookName, http){
		
		http({
			method: 'POST',
			url: document.getElementById('tableauSvc').value+'Tableau/getViewsForWorkBook',
			headers: {'Content-Type':'application/json'},
			data: {"workbookId" : workbookId} 
		}).success(function(response){				
			for (var i=0;i<1;i++) {												
				if (document.getElementById('a_' +workbookId) != null && response != "" && response != null) {					
					document.getElementById('a_' +workbookId).href = "#/tableau/" + workbookName + "/FinanceCIP/" + response[i].contentUrl.split('/')[0] + '|' + response[i].contentUrl.split('/')[2];
				}
			}						
		}).error(function(response){						
			document.getElementById('a_' +workbookid).href = "";
		});
	}

	function getBase64Img(workbookid, preview, token,http){
		http({
			method: 'POST',
			url: document.getElementById('tableauSvc').value+'Tableau/getPreviewImageBase64',
			headers: {'Content-Type':'application/json'},
			data: {"url" : preview} 
		}).success(function(response){				
			var arrayBuffer = response;				
			var mimetype="image/png"; // or whatever your image mime type is						
			if (document.getElementById('img_' +workbookid) != null) {
				document.getElementById('img_' +workbookid).src = "data:"+mimetype+";base64,"+response;						
			}			
		}).error(function(response){						
			document.getElementById('a_' +workbookid).href = "";
		});
	}

function getBase64Img_old(workbookid, preview, token){
	var retURL = "";
	var oReq = new XMLHttpRequest();
	oReq.open("GET", preview, true);
	oReq.setRequestHeader("X-Tableau-Auth", token);
	// use multiple setRequestHeader calls to set multiple values
	oReq.responseType = "arraybuffer";
	oReq.onload = function (oEvent) {
	  var arrayBuffer = oReq.response; // Note: not oReq.responseText
	  if (arrayBuffer) {
		var u8 = new Uint8Array(arrayBuffer);
		var b64encoded = btoa(String.fromCharCode.apply(null, u8));
		var mimetype="image/png"; // or whatever your image mime type is		
		if (document.getElementById('img_' +workbookid) != null) {
			document.getElementById('img_' +workbookid).src = "data:"+mimetype+";base64,"+b64encoded;						
		}
	  }
	};
	oReq.send(null);	
	return retURL;
}

var viz;
//Default call goes to tableauController
fcipApp.controller('tableauController',function($scope,$rootScope,$routeParams, $http) {	
	$rootScope.navpagname = $rootScope.pagename;
	$rootScope.navpagnameURL = $rootScope.pagenameURL;	
	document.getElementById('a_navpagenameURL').href = $rootScope.pagenameURL;
	$rootScope.pagenameURL = "";
	$rootScope.pagename = $routeParams.menu;
	
	var tableauToken = "";
	var TableauServer = (isTableauSecure == 'Y' ? "https://" : "http://") + wgserver +"/trusted/";
	var viewName = "/views/" +  $routeParams.viewname.split('|')[0] + "/" + $routeParams.viewname.split('|')[1] + "?:embed=y&:display_count=no#5";	
	var params = "?:embed=yes&:toolbar=no&:customViews=no";			
	var Auth_URL = tabkeyApi;/*"http://eu9sacexn02.ebiz.verizon.com:7002/analyticsTableauKey/TableauKey";*/ 
	var keyURL = Auth_URL + "?username=" + uVZID + "&wgserver=" + wgserver + "&target_site=" + $routeParams.site + "&secure="+ isTableauSecure +"&Submit=Submit+Query";		
		
	getTableauKey(keyURL,TableauServer,viewName,params);
	
});//End main controller

function initViz(tabURL,tabID) {	
	if (typeof(tabID) == 'undefined') { tabID = 'vizContainer'}
    var containerDiv = document.getElementById(tabID);
    var    url = tabURL;
    var    options = {
            hideTabs: false,
            onFirstInteractive: function () {
                console.log("Run this code when the viz has finished loading.");
            }
    };    
    viz = new tableau.Viz(containerDiv, url, options);
    window.setTimeout(function(){resizeViz();},1000);
    // Create a viz object and embed it in the container div.
}	

function  getTableauKey(keyURL,TableauServer,viewName,params){
	jQuery.support.cors = true;
	jQuery.ajax({ 	// start 2
		url: keyURL,			
		dataType : 'json',	
		type: 'get',
		cache: false,
		success: function (stockInfo) {				
			tableauToken = stockInfo;	                   						
			initViz(TableauServer + tableauToken + "/t/" + sitename + viewName + params);
		},error: function (request, textStatus, errorThrown) {				
			if(request.status=='200'){	
				var tableauToken = request.responseText;
				initViz(TableauServer + tableauToken + "/t/" + sitename + viewName + params);
			}
		},
		complete: function (request, textStatus) {
			//alert("complete" + request.responseText);
			//alert("complete" + textStatus);
	
	
		}
	});
}

jQuery(window).resize(function () {
	window.setTimeout(function(){resizeViz();},1000);		
});

function resizeViz(){		
	
	var zoomLev = (screen.width/parseInt($('#vizContainer').find('iframe').css('width'))) ;
	/*
	zoomLev="0.95";
	$('#vizContainer').css('zoom',1);					
	$('#vizContainer').css('-ms-zoom',zoomLev);
	$('#vizContainer').css('-moz-transform', 'scale(' + zoomLev + ')');
	$('#vizContainer').css('-webkit-transform','scale(' + zoomLev + ')');			
	
	
	$('#vizContainer').find('iframe').css('zoom', 1);
	$('#vizContainer').find('iframe').css('-ms-zoom',zoomLev);
	$('#vizContainer').find('iframe').css('-moz-transform', 'scale(' + zoomLev + ')');
	$("#tabframe").find('iframe').css('-webkit-transform','scale(' + zoomLev + ')');
	viz.setFrameSize($('#vizContainer').width()+50, $('#vizContainer').height());							
	*/
			
		
}

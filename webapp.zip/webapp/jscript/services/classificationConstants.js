'use strict';

fcipApp.constant('classificationConstants', {
  manualUrl : 'https://VSVMCAPI-dev.cfappstdcnpz1.ebiz.verizon.com',
  taxonomyUrl : 'https://VSVTNAPI-dev.cfappstdcnpz1.ebiz.verizon.com',
  businessUrl : 'https://VSVBRAPI-dev.cfappstdcnpz1.ebiz.verizon.com',
  access : {
    viewBR : 'view_br',
    editBR : 'edit_br',
    viewMC : 'view_mc',
    editMC : 'edit_mc',
    viewTN : 'view_tn'
  }
});

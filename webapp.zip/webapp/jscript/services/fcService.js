﻿'use strict';



fcipApp.factory('contentFactory', function ($http, $q) { 

    var theFactory = {};


    theFactory.postContent = function (contentWebservice) {
        var df = $q.defer();
        $http({
            method : "POST",
            url : contentWebservice + "getQueryList",
            headers:{'Content-Type':'application/x-www-form-urlencoded'},
            data: 'queryId= 4'
        })
        .success(function(response){    
            theFactory.fcipcontent = response;                        
            df.resolve();
        }).error(function(response){
            console.log("ERROR: Could not get connection to backend");
        });
        return df.promise;
    };


    theFactory.getContent = function (keyId, contentWebservice) {
        var df = $q.defer();
        $http({
            method : "GET",
            url : contentWebservice + "getContent?keyId=" + keyId
        })
        .success(function(response){    
            theFactory.justcontent = response;                        
            df.resolve();
            console.log("response: " + response);
        }).error(function(response){
            console.log("ERROR: Could not get connection to backend");
        });
        return df.promise;
    };





    return theFactory;

});


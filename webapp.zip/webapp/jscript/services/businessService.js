'use strict';

    fcipApp.factory('businessFactory', function($http, $q, classificationConstants) {

        var serviceFactory = {};
        var businessRulesList = [];

        serviceFactory.getBusinessRules = function() {

                var df = $q.defer();
                $http({
                        method: "POST",
                        url: classificationConstants.businessUrl + "/getBusinessRules",
                        //url : classificationConstants.businesscCustomUrl,
                        headers: {
                            'Content-Type': 'application/json',
                            'Cache-Control' : 'no-cache'
                        },
                        data: {}
                    })
                    .then(
                        function(response) {
                            df.resolve(response);
                        },
                        function(response) {
                            console.log('ERROR - Couldn\'t get Business Rules');
                            df.reject(response);
                        }
                    );

                return df.promise;
            },


            serviceFactory.addBusinessRule = function(rulesObj) {
                rulesObj.creator = "Kumar"; // To be Dynamic
                rulesObj.owner = "Kumar"; // To be Dynamic
                rulesObj.is_active = "Y";
                rulesObj.record_insert_datetime = null;
                rulesObj.created_by = null; //To Be Dynamic
                rulesObj.modified_by = null;
                rulesObj.comments = null;
                console.log(rulesObj);
                var toSend = [rulesObj];

                var df = $q.defer();
                $http({
                        method: "POST",
                        url: classificationConstants.businessUrl + "/insertBusinessRule",
                        headers: {
                            'Content-Type': 'application/json'
                        },
                        data: toSend
                    })
                    .then(
                        function(response) {
                            df.resolve(response);
                        },
                        function(response) {
                            console.log('ERROR - Couldn\'t add Business Rules');
                            df.reject(response);
                        }
                    );

                return df.promise;
            };

        serviceFactory.updateBusinessRule = function(rulesObj) {
            var toSend = [rulesObj];
            console.log(toSend)

            var df = $q.defer();
            $http({
                    method: "POST",
                    url: classificationConstants.businessUrl + "/updateBusinessRule",
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    data: toSend
                })
                .then(
                    function(response) {
                        df.resolve(response);
                    },
                    function(response) {
                        console.log('ERROR - Couldn\'t update Business Rules');
                        df.reject(response);
                    }
                );

            return df.promise;
        };


        serviceFactory.deleteBusinessRule = function(rulesObj) {
            var toSend = [{
                "rule_id": rulesObj.rule_id,
                "modified_by": rulesObj.modified_by,
                "comments": rulesObj.comments
            }];

            var df = $q.defer();
            $http({
                    method: "POST",
                    url: classificationConstants.businessUrl + "/deleteBusinessRule",
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    data: toSend
                })
                .then(
                    function(response) {
                        df.resolve(response);
                    },
                    function(response) {
                        console.log('ERROR - Couldn\'t Delete Business Rules');
                        df.reject(response);
                    }
                );

            return df.promise;
        };

        serviceFactory.recreationBusinessRule = function(rulesObj) {
            var toSend = [{
                "rule_id": rulesObj.rule_id,
                "modified_by": rulesObj.modified_by,
                "comments": rulesObj.comments
            }];

            console.log('---DEBUG---', toSend);

            var df = $q.defer();
            $http({
                    method: "POST",
                    url: classificationConstants.businessUrl + "/unDeleteBusinessRule",
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    data: toSend
                })
                .then(
                    function(response) {
                        df.resolve(response);
                    },
                    function(response) {
                        console.log('ERROR - Couldn\'t Delete Business Rules');
                        df.reject(response);
                    }
                );

            return df.promise;
        };

        serviceFactory.getBusinessRulesList = function() {
            return businessRulesList
        };

        serviceFactory.setBusinessRulesList = function(list) {
            businessRulesList = list;
        };

        return serviceFactory;

    });

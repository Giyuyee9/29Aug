'use strict';
    fcipApp.factory('taxonomyFactory',function($rootScope, $http, $q, classificationConstants) {

     var serviceFactory = {};

        var taxonomyList = [];

      // Akhil
    serviceFactory.getTaxonomy = function() {
        var df = $q.defer();
        $http({
            method: 'POST',
            url: classificationConstants.taxonomyUrl + '/getTaxonomyCodes',
            headers: {'Content-Type':'application/json'},
            data: {}
        })
        .then(
        function(response) {
            df.resolve(response);
        },
        function(response) {
            console.log('ERROR - Couldn\'t get taxonomy codes');
            df.reject(response);
        });

        return df.promise;
    };

        serviceFactory.getTaxonomyList = function(){
            return taxonomyList;
        };

        serviceFactory.setTaxonomyList = function(list){
            taxonomyList = list;
        };

      return serviceFactory;
});

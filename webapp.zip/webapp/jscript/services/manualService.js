'use strict';

  fcipApp.factory('manualFactory',function($rootScope, $http, $q, classificationConstants) {

    var serviceFactory = {};

    // Format the given filters into a where clause
    serviceFactory.formatFilters = function(start, end, filters) {
      var formatted = {};
      // Start with only manual classification records
      var where = "taxonomy_code is null and issourceable_vzn = 'Y' and (automation_flag = 'Pre_classified_NonLvl4' or automation_flag is null) and ";

      // Add page counts for the API
      if (start != null && end != null) {
        formatted['start_page_count'] = start.toString();
        formatted['end_page_count'] = end.toString();
      }

      for (var i=0; i<filters.length; i++) {
        // Get the comparator
        var comparator = filters[i].mid;

        // Filter wasn't used, move on
        if (filters[i].left == 'Select Filter') {
          continue;
        }

        // Change the comparator into a SQL friendly comparator
        if (filters[i].mid == 'equals' || filters[i].mid == 'equals (=)') {
          comparator = '=';
        } else if (filters[i].mid == 'does not equal' || filters[i].mid == 'does not equal (!=)') {
          comparator = '<>';
        } else if (filters[i].mid == 'is less than (<)') {
          comparator = '<';
        } else if (filters[i].mid == 'is greater than (>)') {
          comparator = '>';
        } else if (filters[i].mid == 'contains') {
          comparator = 'like';
        } else if (filters[i].mid == 'does not contain') {
          comparator = 'not like';
        }

        // Change the filter column selection into the DB column
        switch (filters[i].left) {
          case 'Supplier Name':
            if (comparator == 'like' || comparator == 'not like') {
              where += "upper(supplier_name) " + comparator + " '%" + filters[i].right.toUpperCase() + "%' and ";
            } else {
              where += "upper(supplier_name) " + comparator + " '" + filters[i].right.toUpperCase() + "' and ";
            }
            break;
          case 'Invoice Description':
            if (comparator == 'like' || comparator == 'not like') {
              where += "upper(invoice_description) " + comparator + " '%" + filters[i].right.toUpperCase() + "%' and ";
            } else {
              where += "upper(invoice_description) " + comparator + " '" + filters[i].right.toUpperCase() + "' and ";
            }
            break;
          case 'GL Account Name':
            if (comparator == 'like' || comparator == 'not like') {
              where += "upper(gl_account_name) " + comparator + " '%" + filters[i].right.toUpperCase() + "%' and ";
            } else {
              where += "upper(gl_account_name) " + comparator + " '" + filters[i].right.toUpperCase() + "' and ";
            }
            break;
          case 'Cost Center':
            if (comparator == 'like' || comparator == 'not like') {
              where += "upper(cost_center_name) " + comparator + " '%" + filters[i].right.toUpperCase() + "%' and ";
            } else {
              where += "upper(cost_center_name) " + comparator + " '" + filters[i].right.toUpperCase() + "' and ";
            }
            break;
          case 'Spend':
            where += "spend " + comparator + " " + filters[i].right + " and ";
            break;
          case 'Line Items':
          where += "lineitems " + comparator + " " + filters[i].right + " and ";
            break;
          case 'Confidence':
            where += "confidence_level " + comparator + " " + filters[i].right + " and ";
            break;
          case 'Taxonomy Code':
            if (comparator == 'like' || comparator == 'not like') {
              where += "upper(taxonomy_code) " + comparator + " '%" + filters[i].right.toUpperCase() + "%' and ";
            } else {
              where += "upper(taxonomy_code) " + comparator + " '" + filters[i].right.toUpperCase() + "' and ";
            }
            break;
          case 'Taxonomy Description':
            if (comparator == 'like' || comparator == 'not like') {
              where += "upper(taxonomy_description) " + comparator + " '%" + filters[i].right.toUpperCase() + "%' and ";
            } else {
              where += "upper(taxonomy_description) " + comparator + " '" + filters[i].right.toUpperCase() + "' and ";
            }
            break;
          // Source systems, we need to 'or' them all
          case 'Source Systems':
            where += "(";
            for (var j=0; j<filters[i].sources.length; j++) {
              if (filters[i].sources[j] == 'PS') {
                where += "source_system = 'PSICE' or source_system = 'PSWRLS' or source_system = 'PSWRLS-PC' or ";
              } else if (filters[i].sources[j] == 'vSAP') {
                where += "source_system = 'VSAP' or ";
              } else if (filters[i].sources[j] == 'nSAP') {
                where += "source_system = 'NSAPB' or ";
              } else if (filters[i].sources[j] == 'iSAP') {
                where += "source_system = 'ISAPB' or ";
              } else if (filters[i].sources[j] == 'CP') {
                where += "source_system = 'CSTPT' or ";
              }
            }
            where = where.substring(0, where.length-4) + ") and ";
            break;
          // Classified status, change the beginning of the where
          case 'Classified Status':
            where = where.substring(where.indexOf('and') + 4);
            if (comparator == 'classified') {
              where = "taxonomy_code is not null and " + where;
            } else if (comparator == 'unclassified') {
              where = "taxonomy_code is null and " + where;
            } else if (comparator == 'all') {
              where = "(taxonomy_code is null or taxonomy_code is not null) and " + where;
            }
            break;
          // Date, make sure not to take the time into account
          case 'Date':
            where += "trunc(created_date) >= to_date('" + filters[i].start + "', 'mm/dd/yyyy') and trunc(created_date) <= to_date('" + filters[i].end + "', 'mm/dd/yyyy') and ";
            break;
        }
      }

      // Remove final 'and ' and order by descending spend
      where = where.substring(0, where.length-4) + "order by spend desc";
      formatted['where_clause'] = where;
      return formatted;
    };

    // API: get records to manually classify
    serviceFactory.getManualInvoices = function(start, end, filters) {
      var toSend = serviceFactory.formatFilters(start, end, filters);
      var df = $q.defer();
      $http({
          method : "POST",
          url : classificationConstants.manualUrl + "/getManualClassificationItems",
          headers: {'Content-Type':'application/json'},
          data: toSend
      })
      .then(
      function(response){
          df.resolve(response);
      },
      function(response){
          console.log('ERROR - Couldn\'t get invoices');
          df.reject(response);
      }
      );

      return df.promise;
    };

    // API: get the confidence level summary table
    serviceFactory.getConfidenceLevels = function() {
        var df = $q.defer();
        $http({
            method: 'POST',
            url: classificationConstants.manualUrl + '/getConfidenceLevelView',
            headers: {'Content-Type':'application/json'},
            data: {}
        })
        .then(
        function(response) {
            df.resolve(response);
        },
        function(response) {
            console.log('ERROR - Couldn\'t get confidence level view');
            df.reject(response);
        });

        return df.promise;
    };

    // API: get the classification level summary table
    // serviceFactory.getClassificationLevels = function() {
    //     var df = $q.defer();
    //     $http({
    //         method: 'POST',
    //         url: classificationConstants.manualUrl + '/getClassificationLevelView',
    //         headers: {'Content-Type':'application/json'},
    //         data: {}
    //     })
    //     .then(
    //     function(response) {
    //         df.resolve(response);
    //     },
    //     function(response) {
    //         console.log('ERROR - Couldn\'t get classification level view');
    //         df.reject(response);
    //     });
    //
    //     return df.promise;
    // };

    // API: get the spend percentage summary table
    // serviceFactory.getSpendPercentages = function() {
    //     var df = $q.defer();
    //     $http({
    //         method: 'POST',
    //         url: classificationConstants.manualUrl + '/getSpendPercentageView',
    //         headers: {'Content-Type':'application/json'},
    //         data: {}
    //     })
    //     .then(
    //     function(response) {
    //         df.resolve(response);
    //     },
    //     function(response) {
    //         console.log('ERROR - Couldn\'t get spend percentage view');
    //         df.reject(response);
    //     });
    //
    //     return df.promise;
    // };

    // API: get the top suppliers summary table
    serviceFactory.getTopSuppliers = function() {
        var df = $q.defer();
        $http({
            method: 'POST',
            url: classificationConstants.manualUrl + '/getSupplierSpendView',
            headers: {'Content-Type':'application/json'},
            data: {}
        })
        .then(
        function(response) {
            df.resolve(response);
        },
        function(response) {
            console.log('ERROR - Couldn\'t get confidence level view');
            df.reject(response);
        });

        return df.promise;
    };

    // API: get the aging summary table
    serviceFactory.getAging = function() {
        var df = $q.defer();
        $http({
            method: 'POST',
            url: classificationConstants.manualUrl + '/getAgingView',
            headers: {'Content-Type':'application/json'},
            data: {}
        })
        .then(
        function(response) {
            df.resolve(response);
        },
        function(response) {
            console.log('ERROR - Couldn\'t get aging view');
            df.reject(response);
        });

        return df.promise;
    };

  // API: get the taxonomy
  serviceFactory.getTaxonomy = function() {
      var df = $q.defer();
      $http({
          method: 'POST',
          url: classificationConstants.taxonomyUrl + '/getTaxonomyCodes',
          headers: {'Content-Type':'application/json'},
          data: {}
      })
      .then(
      function(response) {
          df.resolve(response);
      },
      function(response) {
          console.log('ERROR - Couldn\'t get taxonomy codes');
          df.reject(response);
      });

      return df.promise;
  };

  // API: get the percent of spend classified
  serviceFactory.getSpendClassified = function() {
    var df = $q.defer();
    $http({
      method: 'POST',
      url: classificationConstants.manualUrl + '/getClassifiedPercentage',
      headers: {'Content-Type': 'application/json'},
      data: {}
    })
    .then(
      function(response) {
        df.resolve(response);
      },
      function(response) {
        console.log('ERROR - Couldn\'t get classified percentage');
        df.reject(response);
      }
    );

    return df.promise;
  };

  // API: get the total record and spend counts
  serviceFactory.getTotalCount = function() {
    var df = $q.defer();
    $http({
      method: 'POST',
      url: classificationConstants.manualUrl + '/getManualClassificationCount',
      headers: {'Content-Type': 'application/json'},
      data: {}
    })
    .then(
      function(response) {
        df.resolve(response);
      },
      function(response) {
        console.log('ERROR - Couldn\'t get classified percentage');
        df.reject(response);
      }
    );

    return df.promise;
  };

  // API: get the record and spend counts for records that need to be classified
  serviceFactory.getManualCount = function() {
    var toSend = {
      'issourceable_vzn': 'Y',
      'automation_flag': 'Pre_classified_NonLvl4'
    };
    var df = $q.defer();
    $http({
      method: 'POST',
      url: classificationConstants.manualUrl + '/getFilteredClassificationCount',
      headers: {'Content-Type': 'application/json'},
      data: toSend
    })
    .then(
      function(response) {
        df.resolve(response);
      },
      function(response) {
        console.log('ERROR - Couldn\'t get classified percentage');
        df.reject(response);
      }
    );

    return df.promise;
  };

  // API: get the record count for the given filters
  serviceFactory.getFilteredCount = function(haveFilters, filters) {
    var toSend = {};
    // No filters, this gets the default count of unclassified records
    if (!haveFilters) {
      toSend = {
        'issourceable_vzn': 'Y',
        'automation_flag': 'Pre_classified_NonLvl4',
        'classification': 'unclassified'
      };
    } else {
      toSend = serviceFactory.formatFilters(null, null, filters);
    }

    var df = $q.defer();
    $http({
      method: 'POST',
      url: classificationConstants.manualUrl + '/getFilteredClassificationCount',
      headers: {'Content-Type': 'application/json'},
      data: toSend
    })
    .then(
      function(response) {
        df.resolve(response);
      },
      function(response) {
        console.log('ERROR - Couldn\'t get classified percentage');
        df.reject(response);
      }
    );

    return df.promise;
  };

  // API: submit the given records using their suggestions
  serviceFactory.submitBySuggestion = function(invoices) {
    var toSend = [];
    for (var i=0; i<invoices.length; i++) {
      var invoiceSend = {};
      invoiceSend['seq_id'] = invoices[i].seq_id;
      invoiceSend['taxonomy_code'] = invoices[i].suggested_taxonomy_code;
      invoiceSend['taxonomy_description'] = invoices[i].suggested_taxonomy_description;
      invoiceSend['comments'] = 'Accepted auto-suggested classification';
      invoiceSend['modified_by'] = currentlyLoginUser;
      toSend.push(invoiceSend);
    }

    var df = $q.defer();
    $http({
      method: 'POST',
      url: classificationConstants.manualUrl + '/updateManualClassificationItems',
      headers: {'Content-Type': 'application/json'},
      data: toSend
    })
    .then(
      function(response) {
        df.resolve(response);
      },
      function(response) {
        console.log('ERROR - Couldn\'t submit changes');
        df.reject(response);
      }
    );

    return df.promise;
  };

  // API: submit the given records using the given taxonomy code
  serviceFactory.submitByCode = function(code, desc, comments, invoices) {
    var toSend = [];
    for (var i=0; i<invoices.length; i++) {
      var invoiceSend = {};
      invoiceSend['seq_id'] = invoices[i].seq_id;
      invoiceSend['taxonomy_code'] = code;
      invoiceSend['taxonomy_description'] = desc;
      invoiceSend['comments'] = comments;
      invoiceSend['modified_by'] = currentlyLoginUser;
      toSend.push(invoiceSend);
    }

    var df = $q.defer();
    $http({
      method: 'POST',
      url: classificationConstants.manualUrl + '/updateManualClassificationItems',
      headers: {'Content-Type': 'application/json'},
      data: toSend
    })
    .then(
      function(response) {
        df.resolve(response);
      },
      function(response) {
        console.log('ERROR - Couldn\'t submit changes');
        df.reject(response);
      }
    );

    return df.promise;
  };

  // API: submit every record matching the given filters with the given code
  serviceFactory.submitByFilters = function(code, desc, comments, filters) {
    var toSend = serviceFactory.formatFilters(null, null, filters);
    // Remove "order by spend desc"
    toSend.where_clause = toSend.where_clause.substring(0, toSend.where_clause.length-20);

    toSend['taxonomy_code_for_update'] = code;
    toSend['taxonomy_description_for_update'] = desc;
    toSend['comments_for_update'] = comments;
    toSend['modified_by_for_update'] = currentlyLoginUser;

    var df = $q.defer();
    $http({
      method: 'POST',
      url: classificationConstants.manualUrl + '/updateFilteredManualClassificationItems',
      headers: {'Content-Type': 'application/json'},
      data: toSend
    })
    .then(
      function(response) {
        df.resolve(response);
      },
      function(response) {
        console.log('ERROR - Couldn\'t submit changes');
        df.reject(response);
      }
    );

    return df.promise;
  };

  // API: flag all classified records to be sent to data lake and truncated
  serviceFactory.submitFinal = function() {
    var df = $q.defer();
    $http({
      method: 'POST',
      url: classificationConstants.manualUrl + '/updateMCInTransmit',
      headers: {'Content-Type': 'application/json'},
      data: {}
    })
    .then(
      function(response) {
        df.resolve(response);
      },
      function(response) {
        console.log('ERROR - Couldn\'t commit classifications');
        df.reject(response);
      }
    );

    return df.promise;
  };

    return serviceFactory;
  });

  // Access Control functions
  fcipApp.service('accessService', function (classificationConstants) {
    var viewBR = function() {
      var accessLevel = classificationConstants.access.viewBR;
      return true;
    }
    var editBR = function() {
      var accessLevel = classificationConstants.access.editBR;
      return true;
    }
    var viewMC = function() {
      var accessLevel = classificationConstants.access.viewMC;
      return true;
    }
    var editMC = function() {
      var accessLevel = classificationConstants.access.editMC;
      return true;
    }
    var viewTN = function() {
      var accessLevel = classificationConstants.access.viewTN;
      return true;
    }

    return {
      viewBR: viewBR,
      editBR: editBR,
      viewMC: viewMC,
      editMC: editMC,
      viewTN: viewTN
    };
  });

  // Caching for the assign page
  fcipApp.service('classifyService', function () {
    var classifyService = {};
    var toClassify = [];
    var taxonomy = [];
    var filters = [];

    // Cache records
    var setInvoices = function (invoices) {
      toClassify = invoices;
    };

    var getInvoices = function () {
      return toClassify;
    };

    // Cache taxonomy
    var setTaxonomy = function (tax) {
      taxonomy = tax;
    };

    var getTaxonomy = function () {
      return taxonomy;
    }

    // Cache filters
    var setFilters = function (filtersUsed) {
      filters = filtersUsed;
    };

    var getFilters = function () {
      return filters;
    }

    return {
      setInvoices: setInvoices,
      getInvoices: getInvoices,
      setTaxonomy: setTaxonomy,
      getTaxonomy: getTaxonomy,
      setFilters: setFilters,
      getFilters: getFilters
    };
  });

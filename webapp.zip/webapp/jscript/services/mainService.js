'use strict';

fcipApp.factory('mainFactory', function ($http, $q, $routeParams) {

    var theFactory = {};

    theFactory.getRole = function (currentlyLoginUser, restWebserviceHostlookup/*, restAppSvc*/) {
        var df = $q.defer();

        $http({
                method: 'POST',
                url: restWebserviceHostlookup+'FCIP/ARA/1.0/LDAP/getUserRole',
                headers: {'Content-Type':'application/json'},
                data: {"eid" : currentlyLoginUser } 

            }).success(function(response){              
                    theFactory.userDetails = response;                                  
                    df.resolve();

            }).error(function(response){
                    theFactory.ResponseDetails = "GetUserRole call -Error:"+response;
                    console.log("ERROR: Could not get connection to back-end for user role");
            });
            return df.promise;
    };

    // theFactory.getMenus = function (currentlyLoginUser, restAppSvc) {
    //     console.log("right after making getMenus function");
    //     var df = $q.defer();
    //     console.log("right after defining $q.defer");
    //     $http({
    //             method: 'POST',
    //             url: restAppSvc+'getMenus',
    //             headers: {'Content-Type':'application/json'},
    //             data: {"eid" : currentlyLoginUser,"appId" : 1} 

    //         }).success(function(response){
    //             console.log("right after calling the success function");
    //             theFactory.userMenus = response.responseObjList;
    //             console.log("right after making a variable with the menu data");
    //             df.resolve();
    //             console.log("right after calling df.resolve");
    //         }).error(function(response){
    //             console.log("ERROR: Could not get connection to back-end for menus");
    //         });
    //         return df.promise;
    // };

    return theFactory;

});

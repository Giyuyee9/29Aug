'use strict';

//Default call goes to mainController
fcipApp.controller('mainController',function($scope,$rootScope,$http) {

	$scope.expandedAll=true;
	$scope.adminLbl=false;
	$scope.userLbl=true;
	$scope.mydisabled=false;  //Admin user toggle
	$scope.progressLbl=true;

	$rootScope.navpagname = "Home";
	$rootScope.navpagnameURL = "#";
	$rootScope.pagename="";
	$rootScope.pagenameURL = "";


	$scope.singoutFn = function(){
		var promise = $http.get(fcipUIHost+'logout');
		promise.then(function(payload){
		currentlyLoginUser=null;
	    document.getElementById("ara_txn_eid_hidden").value = null;
	    window.location.assign("Logout.html");
	    alert("You've been logged out successfully");
		});
	}

	$scope.actAsAdminFn = function(){
		actasadmin = true;
		$scope.adminLbl=true;
		$scope.userLbl=false;
		alert("Now you have the admin privileges!");
		$scope.$broadcast("REFRESH");
	}

	$scope.actAsUserFn= function(){
		actasadmin = false;
		$scope.adminLbl=false;
		$scope.userLbl=true;
		alert("Admin privileges released!");
		$scope.$broadcast("REFRESH");
	}
	currentlyLoginUser=document.getElementById("ara_txn_eid_hidden").value;
	restWebserviceHostlookup=document.getElementById("ara_ldap_host_hidden").value;
	restAppSvc	=document.getElementById("appSrvApi").value;
	appId=document.getElementById("appId").value;
	fcipUIHost=document.getElementById("ara_ui_host_hidden").value;
	wgserver=document.getElementById("tableauServer").value;
	tabkeyApi=document.getElementById("tableauKeyApi").value;
	sitename=document.getElementById("tableauSite").value;
	isTableauSecure=document.getElementById("tableauSECURE").value;

	/*Test Data	*/
	/*restWebserviceHost="https://fciparatxnws-dev.cfappstpanpz1.ebiz.verizon.com/";
	currentlyLoginUser="3590639062";
	restWebserviceHostlookup="https://fciparaldapws-dev.cfappstpanpz1.ebiz.verizon.com/";
	restWebserviceHostapp="https://fcipfcipAppws-dev.cfappstpanpz1.ebiz.verizon.com/";
	restWebserviceHostrep="https://fcipararepws-sit.cfappstpanpz1.ebiz.verizon.com/";*/

	if(restWebserviceHost==="null"){
		alert("Error : Unable to read hostname(restWebserviceHost) from environment variable");
		 var uhost = prompt("Please enter HostName", "");
		    if (uhost != null) {
		    	restWebserviceHost=uhost;
		    }
	}
	$scope.initialized = true;
	if(currentlyLoginUser==="null"){


		/* for local comment this call
		var promise = $http.get(fcipUIHost+'getEid');
		promise.then(function(payload){
		*/
			/* for local comment this value
			$scope.userName=payload.data;
			currentlyLoginUser =  payload.data   ;
			*/
			// currentlyLoginUser = '2638303915';
      currentlyLoginUser = '2391533222';

			var userEid = {
					"eid" : currentlyLoginUser
				};

			$scope.progressLbl=false;

			$scope.parJson = function (json) {
				return JSON.parse(json);
			};

			$http({
				method: 'POST',
				url: restWebserviceHostlookup+'FCIP/ARA/1.0/LDAP/getUserRole',
				headers: {'Content-Type':'application/json'},
				data: userEid
			}).success(function(response){
				$scope.userDetails = response;
				$scope.progressLbl=true;
				uVZID = $scope.userDetails.userid;

				$http({
					method: 'POST',
					url: restAppSvc+'getMenus',
					headers: {'Content-Type':'application/json'},
					data: {"eid" : currentlyLoginUser,"appId" : appId}
				}).success(function(response){
					$scope.userMenus = response.responseObjList;
					$scope.initialized = true;
				}).error(function(response){
					$scope.progressLbl=true;
					$scope.initialized = true;
				});

			}).error(function(response){
				$scope.ResponseDetails = "GetUserRole call -Error:"+response;
				$scope.progressLbl=true;
			});

		/*}); local comment*/
	}



	if(restWebserviceHostlookup==="null"){
		alert("Error : Unable to read hostname(restWebserviceHostlookup) from environment variable");
		 var uhost = prompt("Please enter HostName", "");
		    if (uhost != null) {
		    	restWebserviceHostlookup=uhost;
		    }
	}

	if(restWebserviceHostapp==="null"){
		alert("Error : Unable to read hostname(restWebserviceHostapp) from environment variable");
		 var uhost = prompt("Please enter HostName", "");
		    if (uhost != null) {
		    	restWebserviceHostapp=uhost;
		    }
	}

	if(restWebserviceHostrep==="null"){
		alert("Error : Unable to read hostname(restWebserviceHostrep) from environment variable");
		 var uhost = prompt("Please enter HostName", "");
		    if (uhost != null) {
		    	restWebserviceHostrep=uhost;
		    }
	}
	/*ara_rep_host_hidden*/


});//End main controller

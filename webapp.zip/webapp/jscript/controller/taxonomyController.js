'use strict';

fcipApp.controller('taxonomyController',function($scope,$timeout,taxonomyFactory,$location,$sce) {
  // Access Rights
  $scope.viewRights = true; // MUST CHANGE ONCE SSO INTEGRATED
  $scope.editRights = true; // MUST CHANGE ONCE SSO INTEGRATED

  if (!$scope.viewRights) {
    $('.vsvcui_taxonomyControllerDeny').css('display','block');
    return;
  }



  $scope.topFunction = function() {
      document.body.scrollTop = 0;
      document.documentElement.scrollTop = 0;
  }
  
  function getTaxonomy() {
        if(taxonomyFactory.getTaxonomyList().length > 0){
            $scope.taxonomyList = taxonomyFactory.getTaxonomyList();
            $timeout(function() {
              $('.vsvcui_taxonomyController').css('display','block');
            }, 500);
        }
        else{
            // Show loading spinner.
            $scope.loading = true;
            taxonomyFactory.getTaxonomy().then(
              function(data){
                //assign value
                $scope.taxonomyList = data.data;
                //Assign values to service factory method for later user
                taxonomyFactory.setTaxonomyList(data.data);
                // Hide loading spinner whether our call succeeded or failed.
                $scope.loading = false;
                $('.vsvcui_taxonomyController').css('display','block');
              },
              function(response){
                console.log(response);
                // Hide loading spinner whether our call succeeded or failed.
                $scope.loading = false;
                $('.vsvcui_taxonomyController').css('display','block');
              }
            );
        }
    };

    // Initial sorting
    $scope.taxReverseSort = false;
    $scope.taxOrderByField = 'code';

    // Initial API calls
    getTaxonomy();

    $scope.goToUrl = function(path){
        $location.path(path);
    };

    function formatDate(date){
        return ("0" + (date.getMonth() + 1)).slice(-2).toString() + ("0" + date.getDate()).slice(-2).toString() + date.getFullYear().toString();
    }
    
    function formatTimeAMPM(date) {
      var hours = date.getHours();
      var minutes = date.getMinutes();
      var ampm = hours >= 12 ? 'pm' : 'am';
      hours = hours % 12;
      hours = hours ? hours : 12; // the hour '0' should be '12'
      minutes = minutes < 10 ? '0'+minutes : minutes;
      var strTime = '_' + ("0" + hours).slice(-2) + '_' + minutes + '_' + ("0" + date.getSeconds()).slice(-2) + ampm.toUpperCase();
      return strTime;
    }
    
    function makeList(list){
        var tempList = [];
        angular.forEach(list,function(value){
            var temp = {};
            temp.code = value.code;
            temp.area = value.area;
            temp.sourcing_group = value.sourcing_group;
            temp.category = value.category;
            temp.function = value.function;
            temp.level1 = value.level1;
            temp.level2 = value.level2;
            temp.level3 = value.level3;
            temp.level4 = value.level4;
            tempList.push(temp);
        });
        return tempList;
    }
    
    $scope.downloadFile = function () {
        if($scope.filtered.length == 0 && $scope.searchText){
            var tempList = [{"code":"","area":"","sourcing_group":"","category":"","function":"","level1":"","level2":"","level3":"","level4":""}];
            var fileName = 'Taxonomy_' + $scope.searchText + '_' + formatDate(new Date()) + formatTimeAMPM(new Date()) +'.xlsx';
            alasql('SELECT * INTO XLSX("' + fileName + '",{headers:true}) FROM ?',[tempList]);   
        }
        else if($scope.filtered.length > 0 && $scope.searchText){
            var fileName = 'Taxonomy_' + $scope.searchText + '_' + formatDate(new Date()) + formatTimeAMPM(new Date()) +'.xlsx';
            alasql('SELECT * INTO XLSX("' + fileName + '",{headers:true}) FROM ?',[makeList($scope.filtered)]);   
        }
        else{
            var fileName = 'Taxonomy_' + formatDate(new Date()) + formatTimeAMPM(new Date()) +'.xlsx';
            alasql('SELECT * INTO XLSX("' + fileName + '",{headers:true}) FROM ?',[makeList($scope.taxonomyList)]);
        }
    };
    
  window.onscroll = function() {scrollFunction()};
	function scrollFunction()
    {
	if(document.getElementById("myBtn"))
    {
		if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20)
        {
            document.getElementById("myBtn").style.display = "block";
		}
        else
        {
			document.getElementById("myBtn").style.display = "none";
		}
	}
    }
});//End taxonomy controller 

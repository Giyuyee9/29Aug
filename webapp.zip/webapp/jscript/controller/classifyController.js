'use strict';

fcipApp.controller('classifyController', function($scope, $window, $location, $timeout, manualFactory, classifyService, accessService) {
  // Access Rights
  $scope.editRights = false;
  $scope.editRights = accessService.editMC();
  if (!$scope.editRights) {
    $('.vsvcui_classifyControllerDeny').css('display','block');
    return;
  }


  // Fix landing on the middle of this page
  $window.scrollTo(0, 0);

  // Spinner
  $scope.loading = false;

  // Classify all records matching current filters
  $scope.classifyAll = false;

  // Keep track of taxonomy code selected
  $scope.selected;
  $scope.oldSearchText = '';

  // Grab the records and filters from cache
  $scope.invoices = classifyService.getInvoices();
  $scope.filters = classifyService.getFilters();

  // Default to all records selected
  $scope.allSelected = true;
  $scope.invoiceSelected = {};
  for (var i=0; i<$scope.invoices.length; i++) {
    $scope.invoiceSelected[$scope.invoices[i].seq_id] = true;
  }

  // Sorting
  $scope.recordsOrderByField = 'spend';
  $scope.recordsReverseSort = true;
  $scope.taxOrderByField = 'code';
  $scope.taxReverseSort = false;

  // Comments
  $scope.commentsText = '';

  // Record table headers
  $scope.dataHeaders = [
    'Supplier',
    'Invoice Description',
    'GL Account',
    'Cost Center',
    'Taxonomy',
    'Spend',
    ' '
  ];

  // Select (deselect) a record
  $scope.toggleInvoiceSelected = function (invoice) {
    if ($scope.invoiceSelected[invoice.seq_id]) {
      $scope.invoiceSelected[invoice.seq_id] = false;
      $scope.allSelected = false;
      return;
    } else {
      $scope.invoiceSelected[invoice.seq_id] = true;
      for (var i=0; i<$scope.invoices.length; i++) {
        if ($scope.invoiceSelected[$scope.invoices[i].seq_id] != true) {
          $scope.allSelected = false;
          return;
        }
      }
    }

    $scope.allSelected = true;
  }

  // Get the count of records selected
  $scope.getInvoicesSelected = function() {
    if ($scope.classifyAll) {
      return $scope.filterRecordCount;
    }

    var total = 0;
    if ($scope.invoiceSelected.length == 0) {
      total = $scope.invoices.length;
    } else {
      for (var i=0; i<$scope.invoices.length; i++) {
        if ($scope.invoiceSelected[$scope.invoices[i].seq_id]) {
          total++;
        }
      }
    }

    return total;
  };

  // Get the count of line items selected
  $scope.getLineItems = function() {
    if ($scope.classifyAll) {
      return $scope.filterLineItemCount;
    }

    var total = 0;
    if ($scope.invoiceSelected.length == 0) {
      for (var i=0; i<$scope.invoices.length; i++) {
        total += $scope.invoices[i].lineitems;
      }
    } else {
      for (var i=0; i<$scope.invoices.length; i++) {
        if ($scope.invoiceSelected[$scope.invoices[i].seq_id]) {
          total += $scope.invoices[i].lineitems;
        }
      }
    }

    return total;
  };

  // Get the count of spend selected
  $scope.getSpend = function() {
    if ($scope.classifyAll) {
      return $scope.filterSpendCount;
    }

    var total = 0;
    if ($scope.invoiceSelected.length == 0) {
      for (var i=0; i<$scope.invoices.length; i++) {
        total += $scope.invoices[i].spend;
      }
    } else {
      for (var i=0; i<$scope.invoices.length; i++) {
        if ($scope.invoiceSelected[$scope.invoices[i].seq_id]) {
          total += $scope.invoices[i].spend;
        }
      }
    }

    return total;
  };

  // Select (deselect) a taxonomy code
  $scope.toggleSelected = function(tax) {
    if ($scope.selected == tax.code) {
      // Already selected, deselect
      $scope.selected = null;
      $scope.searchText = $scope.oldSearchText;
    } else {
      $scope.selected = tax.code;
      $scope.oldSearchText = $scope.searchText;
      $scope.searchText = tax.code;
    }
  };

  // API: get the counts for all records matching these filters
  $scope.classifyAllMatches = function() {
    if ($scope.classifyAll) {
      manualFactory.getFilteredCount(true, $scope.filters).then(
        function(data) {
          $scope.filterRecordCount = data.data[0].TOTAL_RECORDS;
          $scope.filterSpendCount = data.data[0].SPEND;
          $scope.filterLineItemCount = data.data[0].LINEITEMS;
        },
        function(response) {
          console.log(response);
        }
      );
    }
  };

  // Get the taxonomy description for a given code
  function getTaxonomyDesc(code) {
    for (var i=0; i<$scope.taxonomy.length; i++) {
      if ($scope.taxonomy[i].code == code) {
        return $scope.taxonomy[i].description;
      }
    }

    return null;
  }

  // API: submit the selected records with the selected taxonomy code
  $scope.submitSelected = function() {
    $scope.loading = true;

    var code_description = getTaxonomyDesc($scope.selected);

    // Classify all records matching these filters
    if ($scope.classifyAll) {
      manualFactory.submitByFilters($scope.selected, code_description, $scope.commentsText, $scope.filters).then(
        function(data) {
          $location.path('/manual');
        },
        function(response) {
          console.log(response);
          $scope.loading = false;
        }
      );
      // Classify all records sent to this controller
    } else if ($scope.allSelected) {
      manualFactory.submitByCode($scope.selected, code_description, $scope.commentsText, $scope.invoices).then(
        function(data) {
          $location.path('/manual');
        },
        function(response) {
          console.log(response);
          $scope.loading = false;
        }
      );
      // Classify only the records selected in the table
    } else {
      var invoicesToSubmit = [];
      var invoicesLeft = [];
      // Group the records based on whether they are selected or not
      for (var i=0; i<$scope.invoices.length; i++) {
        if ($scope.invoiceSelected[$scope.invoices[i].seq_id]) {
          invoicesToSubmit.push($scope.invoices[i]);
        } else {
          invoicesLeft.push($scope.invoices[i]);
        }
      }

      // No records were selected, inform user
      if (invoicesToSubmit.length == 0) {
        $scope.loading = false;
        $scope.toastMsg = 'Please select at least 1 record';
        $scope.toastTrigger = 1;
        $timeout(function() {
          $scope.toastTrigger = 0;
        }, 3000);
        return;
      }

      // Submit the records
      manualFactory.submitByCode($scope.selected, code_description, $scope.commentsText, invoicesToSubmit).then(
        function(data) {
          // Set the current working set to the records that are left
          $scope.invoices = invoicesLeft;
          // Select all records again
          $scope.allSelected = true;
          for (var i=0; i<$scope.invoices.length; i++) {
            $scope.invoiceSelected[$scope.invoices[i].seq_id] = true;
          }
          // Deselect taxonomy code
          $scope.selected = null;
          $scope.searchText = $scope.oldSearchText;
          // Reset comments field
          $scope.commentsText = '';
          // Inform user of submission success
          if (invoicesToSubmit.length == 1) {
            $scope.toastMsg = 'Classified 1 Record';
          } else {
            $scope.toastMsg = 'Classified ' + invoicesToSubmit.length + ' Records';
          }
          $scope.loading = false;
          $scope.toastTrigger = 1;
          $timeout(function() {
              $scope.toastTrigger = 0;
          }, 3000);
        },
        function(response) {
          console.log(response);
          $scope.loading = false;
        }
      );
    }
  }

  // Try getting the taxonomy from cache
  $scope.taxonomy = classifyService.getTaxonomy();
  // Get taxonomy again if user went too fast to cache it
  if ($scope.taxonomy.length == 0) {
    $scope.loading = true;
    manualFactory.getTaxonomy().then(
      function(data) {
        $scope.taxonomy = data.data;
        $('.vsvcui_classifyController').css('display','block');
        $scope.loading = false;
      },
      function(response) {
        console.log(response);
        $('.vsvcui_classifyController').css('display','block');
        $scope.loading = false;
      }
    );
  } else {
    $timeout(function() {
      $('.vsvcui_classifyController').css('display','block');
    }, 500);
  }
}); //End classify controller

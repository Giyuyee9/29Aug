'use strict';

fcipApp.controller('accordionController',function($scope,$location,$timeout,taxonomyFactory) {
  // Access Rights
  $scope.viewRights = true; // MUST CHANGE ONCE SSO INTEGRATED
  $scope.editRights = true; // MUST CHANGE ONCE SSO INTEGRATED

  if (!$scope.viewRights) {
    $('.vsvcui_accordionControllerDeny').css('display','block');
    return;
  }

    var list=[];
    $scope.viewByArea={};
    $scope.viewByLevel={};

   $scope.topFunction = function () {
        document.body.scrollTop = 0;
        document.documentElement.scrollTop = 0;
    }
   



 function getTaxonomy() {
        // Show loading spinner.
        $scope.loading = true;
        if(taxonomyFactory.getTaxonomyList().length > 0){
            list = taxonomyFactory.getTaxonomyList();
            formatData(list);
            $timeout(function() {
              $('.vsvcui_accordionController').css('display','block');
            }, 500);
        }
        else{
            taxonomyFactory.getTaxonomy().then(
              function(data){
                //assign value to temporary list
                list = data.data;
                formatData(list);
                $('.vsvcui_accordionController').css('display','block');
              },
              function(response){
                console.log(response);
                // Hide loading spinner whether our call succeeded or failed.
                $scope.loading = false;
                $('.vsvcui_accordionController').css('display','block');
              }
            );
        }
    };

    function formatData(list){
        //View By Level
        for(var i=0;i<list.length;i++){
            if($scope.viewByLevel[list[i].level1])
            {
                if(!list[i].level1){
                    list[i].level1 = 'Unclassified';
                }
                if(!list[i].level2){
                    list[i].level2 = 'Unclassified';
                }
                if(!list[i].level3){
                    list[i].level3 = 'Unclassified';
                }
              if(!$scope.viewByLevel[list[i].level1][list[i].level2]){
                $scope.viewByLevel[list[i].level1][list[i].level2] = {};
              }
              if(!$scope.viewByLevel[list[i].level1][list[i].level2][list[i].level3]){
                $scope.viewByLevel[list[i].level1][list[i].level2][list[i].level3] = [];
              }
                if(!list[i].level4){
                    list[i].level4 = 'Unclassified';
                }
              var temp = {'code':list[i].code, 'description':list[i].level4};
              $scope.viewByLevel[list[i].level1][list[i].level2][list[i].level3].push(temp);
            }
            else
            {
                if(!list[i].level1){
                    list[i].level1 = 'Unclassified';
                }
                if(!list[i].level2){
                    list[i].level2 = 'Unclassified';
                }
                if(!list[i].level3){
                    list[i].level3 = 'Unclassified';
                }

              $scope.viewByLevel[list[i].level1] = {};
              $scope.viewByLevel[list[i].level1][list[i].level2] = {};
              if(!list[i].level4){
                list[i].level4 = 'Unclassified';
              }
              $scope.viewByLevel[list[i].level1][list[i].level2][list[i].level3]=[{'code':list[i].code,'description':list[i].level4}];
            }
          }
        for (var key1 in $scope.viewByLevel){
            var level1 = $scope.viewByLevel[key1];
            for(var key2 in level1){
                var level2 = level1[key2];
                for(var key3 in level2){
                    var level3 = level2[key3];
                    for(var key4=0; key4<level3.length; key4++){
                        if(key2 == 'Unclassified'){
                            var new_key = level3[key4].code + ' - ' + key1;
                            Object.defineProperty($scope.viewByLevel, new_key,Object.getOwnPropertyDescriptor($scope.viewByLevel, key1));
                            delete $scope.viewByLevel[key1];
                        }
                        if(key3 == 'Unclassified'){
                            var new_key = level3[key4].code + ' - ' + key2;
                            Object.defineProperty(level1, new_key,Object.getOwnPropertyDescriptor(level1, key2));
                            delete level1[key2];
                        }
                        if(level3[key4].description == 'Unclassified'){
                            var new_key = level3[key4].code + ' - ' + key3;
                            Object.defineProperty(level2, new_key,Object.getOwnPropertyDescriptor(level2, key3));
                            delete level2[key3];
                        }
                    }
                }
            }

        }


        //View By Area
        for(var i=0;i<list.length;i++){
            if($scope.viewByArea[list[i].area])
            {
              if(!$scope.viewByArea[list[i].area][list[i].sourcing_group]){
                $scope.viewByArea[list[i].area][list[i].sourcing_group] = {};
              }
              if(!$scope.viewByArea[list[i].area][list[i].sourcing_group][list[i].category]){
                $scope.viewByArea[list[i].area][list[i].sourcing_group][list[i].category] = [];
              }
                if(!list[i].level4){
                    list[i].level4 = 'Unclassified';
                }
              var temp = {'code':list[i].code, 'description':list[i].level4};
              $scope.viewByArea[list[i].area][list[i].sourcing_group][list[i].category].push(temp);

            }
            else
            {
                if(!list[i].area){
                    list[i].area = 'Unclassified';
                }
                if(!list[i].sourcing_group){
                    list[i].sourcing_group = 'Unclassified';
                }
                if(!list[i].category){
                    list[i].category = 'Unclassified';
                }
              $scope.viewByArea[list[i].area] = {};
              $scope.viewByArea[list[i].area][list[i].sourcing_group] = {};
                if(!list[i].level4){
                    list[i].level4 = 'Unclassified';
                }
              $scope.viewByArea[list[i].area][list[i].sourcing_group][list[i].category]=[{'code':list[i].code,'description':list[i].level4}];
            }
          }

         $scope.mainObjectLevel = $scope.viewByLevel;
        $scope.mainObjectArea = $scope.viewByArea;

        // Hide loading spinner whether our call succeeded or failed.
        $scope.loading = false;
    }

    // Initial API calls
    getTaxonomy();

    $scope.goToUrl = function(path){
        $location.path(path);
    };

    $scope.getLength = function(obj){
        if(obj.hasOwnProperty('isCollapsibleOpen')){
            return Object.keys(obj).length - 1;
        }
        else{
            return Object.keys(obj).length;
        }
    };

       $scope.collapseAll = function(){
        if($scope.showViewByLevel){
            for (let i in $scope.viewByLevel) {
                $scope.viewByLevel[i].isCollapsibleOpen = false;
                for (let j in $scope.viewByLevel[i]) {
                    if (j != 'isCollapsibleOpen') {
                        $scope.viewByLevel[i][j].isCollapsibleOpen = false;
                        for (let k in $scope.viewByLevel[i][j]) {
                            if (k != 'isCollapsibleOpen') {
                                $scope.viewByLevel[i][j][k].isCollapsibleOpen = false;
                            }
                        }
                    }
                }
            }
        }
        else if($scope.showViewByArea){
            for (let i in $scope.viewByArea) {
                $scope.viewByArea[i].isCollapsibleOpen = false;
                for (let j in $scope.viewByArea[i]) {
                    if (j != 'isCollapsibleOpen') {
                        $scope.viewByArea[i][j].isCollapsibleOpen = false;
                        for (let k in $scope.viewByArea[i][j]) {
                            if (k != 'isCollapsibleOpen') {
                                $scope.viewByArea[i][j][k].isCollapsibleOpen = false;
                            }
                        }
                    }
                }
            }
        }

    };

//    $scope.filter = function(object, filter) {
//        if (!object) return {};
//        if (!filter) return object;
//
//        var filteredObject = {};
//        Object.keys(object).forEach(function(key) {
//          if (key.toLowerCase().includes(filter.toLowerCase())) {
//            filteredObject[key] = object[key];
//          }
//        });
//        return filteredObject;
//  };

    $scope.nestedSearch = function(searchIn, q) {
        if (Array.isArray(searchIn)) {
            return searchIn.filter(function(k) {
                return k.description && k.description.toLowerCase().includes(q.toLowerCase()) || k.code && k.code.toLowerCase().includes(q.toLowerCase());
            }).length > 0;
        } else if (typeof searchIn == 'object') {
            for (let j in searchIn) {
                if (j.toLowerCase().includes(q.toLowerCase()) || $scope.nestedSearch(searchIn[j], q)) {
                    return true;
                }
            }
        } else if (typeof searchIn == 'string') {
            return searchIn.toLowerCase().includes(q.toLowerCase());
        }
        return false;
    };

    $scope.backUpObj = null;

    $scope.search = function() {
        $scope.searchedResults = {};
        if($scope.searchText){
            if($scope.showViewByLevel){
                $scope.viewByLevel = $scope.mainObjectLevel;
                for (let k in $scope.viewByLevel){
                    let v = $scope.viewByLevel[k];
                    if (k.toLowerCase().includes($scope.searchText.toLowerCase()) || $scope.nestedSearch(v, $scope.searchText)) {
                        var arrTemp= {};
                        for(let key in v){
                            if(key.toLowerCase().includes($scope.searchText.toLowerCase())){
                                arrTemp[key] = v[key];
                            }
                            else{
                                if($scope.nestedSearch(v[key], $scope.searchText)){
                                    for(let key2 in v[key]){
                                        if(key2.toLowerCase().includes($scope.searchText.toLowerCase())){
                                            if(!arrTemp[key]){
                                              arrTemp[key] = {};
                                            }
                                            arrTemp[key][key2] = v[key][key2];
                                        }
                                        else{
                                            for(let i=0;i<v[key][key2].length;i++){
                                                if(v[key][key2][i].description.toLowerCase().includes($scope.searchText.toLowerCase()) || v[key][key2][i].code.toLowerCase().includes($scope.searchText.toLowerCase())){
                                                    if(!arrTemp[key]){
                                                      arrTemp[key] = {};
                                                    }
                                                    if(!arrTemp[key][key2]){
                                                      arrTemp[key][key2] = [];
                                                    }
                                                    arrTemp[key][key2].push(v[key][key2][i]);
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        $scope.searchedResults[k] = arrTemp;
                    }
                }
                $scope.viewByLevel = $scope.searchedResults;
            }
            else if($scope.showViewByArea){
                $scope.viewByArea = $scope.mainObjectArea;
                for (let k in $scope.viewByArea){
                    let v = $scope.viewByArea[k];
                    if (k.toLowerCase().includes($scope.searchText.toLowerCase()) || $scope.nestedSearch(v, $scope.searchText)) {
                        var arrTemp= {};
                        for(let key in v){
                            if(key.toLowerCase().includes($scope.searchText.toLowerCase())){
                                arrTemp[key] = v[key];
                            }
                            else{
                                if($scope.nestedSearch(v[key], $scope.searchText)){
                                    for(let key2 in v[key]){
                                        if(key2.toLowerCase().includes($scope.searchText.toLowerCase())){
                                            if(!arrTemp[key]){
                                              arrTemp[key] = {};
                                            }
                                            arrTemp[key][key2] = v[key][key2];
                                        }
                                        else{
                                            for(let i=0;i<v[key][key2].length;i++){
                                                if(v[key][key2][i].description.toLowerCase().includes($scope.searchText.toLowerCase()) || v[key][key2][i].code.toLowerCase().includes($scope.searchText.toLowerCase())){
                                                    if(!arrTemp[key]){
                                                      arrTemp[key] = {};
                                                    }
                                                    if(!arrTemp[key][key2]){
                                                      arrTemp[key][key2] = [];
                                                    }
                                                    arrTemp[key][key2].push(v[key][key2][i]);
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        $scope.searchedResults[k] = arrTemp;
                    }
                }
                $scope.viewByArea = $scope.searchedResults;
            }
        }
    };

    $scope.resetSearch = function(){
        if(!$scope.searchText){
            if($scope.showViewByLevel){
                $scope.viewByLevel = $scope.mainObjectLevel;
            }
            else if($scope.showViewByArea){
                $scope.viewByArea = $scope.mainObjectArea;
            }
        }
    };

   window.onscroll = function () {
        scrollFunction()
    };

    function scrollFunction() {
        if (document.getElementById("myBtn") || document.getElementById("myBtn1")) {
            if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
                document.getElementById("myBtn").style.display = "block";
                document.getElementById("myBtnDown").style.display = "block";
            } else {
                document.getElementById("myBtn").style.display = "none";
                document.getElementById("myBtnDown").style.display = "none";
            }
        }
    }
    
});
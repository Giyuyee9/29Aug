'use strict';

fcipApp.controller('iframeController',function($scope,$rootScope, $route, $routeParams, $http) {
	
	if($route.current.$$route.breadcum == "Summary"){
		$rootScope.navpagname = "Home";
		$rootScope.navpagnameURL = "#";
		$rootScope.pagenameURL = "#/spenddashboard";	
		$rootScope.pagename = "Spend Summary";
	}else if($route.current.$$route.breadcum == "Invoice Spend"){
		$rootScope.navpagname = "Data management";
		$rootScope.navpagnameURL = "#/spenddashboard";		
		$rootScope.pagenameURL = "#/spendvalidation";	
		$rootScope.pagename = "Invoice Spend";
	}else {
		$rootScope.navpagname = "Data management";
		$rootScope.navpagnameURL = "#/spenddashboard";
		$rootScope.pagenameURL = "#/povalidation";	
		$rootScope.pagename = "Purchase Order Spend";
	} 	
	document.getElementById('a_navpagenameURL').href = $rootScope.pagenameURL;
});
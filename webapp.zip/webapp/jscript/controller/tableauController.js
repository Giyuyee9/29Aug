'use strict';

var viz;
//Default call goes to tableauController
fcipApp.controller('tableauController',function($scope,$rootScope,$routeParams, $http) {	
	$rootScope.navpagname = $rootScope.pagename;
	$rootScope.navpagnameURL = $rootScope.pagenameURL;	
	document.getElementById('a_navpagenameURL').href = $rootScope.pagenameURL;
	$rootScope.pagenameURL = "";
	$rootScope.pagename = $routeParams.menu;
	
	var tableauToken = "";
	var TableauServer = (isTableauSecure == 'Y' ? "https://" : "http://") + wgserver +"/trusted/";
	var viewName = "/views/" +  $routeParams.viewname.split('|')[0] + "/" + $routeParams.viewname.split('|')[1] + "?:embed=y&:display_count=no#5";	
	var params = "?:embed=yes&:toolbar=no&:customViews=no";			
	var Auth_URL = tabkeyApi;/*"http://eu9sacexn02.ebiz.verizon.com:7002/analyticsTableauKey/TableauKey";*/ 
	var keyURL = Auth_URL + "?username=" + uVZID + "&wgserver=" + wgserver + "&target_site=" + $routeParams.site + "&secure="+ isTableauSecure +"&Submit=Submit+Query";		
		
	getTableauKey(keyURL,TableauServer,viewName,params);
	
});//End main controller


function initViz(tabURL,tabID) {	
	if (typeof(tabID) == 'undefined') { tabID = 'vizContainer'}
    var containerDiv = document.getElementById(tabID);
    var    url = tabURL;
    var    options = {
            hideTabs: false,
            onFirstInteractive: function () {
                console.log("Run this code when the viz has finished loading.");
            }
    };    
    viz = new tableau.Viz(containerDiv, url, options);
    window.setTimeout(function(){resizeViz();},1000);
    // Create a viz object and embed it in the container div.
}

function  getTableauKey(keyURL,TableauServer,viewName,params){
	jQuery.support.cors = true;
	jQuery.ajax({ 	// start 2
		url: keyURL,			
		dataType : 'json',	
		type: 'get',
		cache: false,
		success: function (stockInfo) {				
			tableauToken = stockInfo;	                   						
			initViz(TableauServer + tableauToken + "/t/" + sitename + viewName + params);
		},error: function (request, textStatus, errorThrown) {				
			if(request.status=='200'){	
				var tableauToken = request.responseText;
				initViz(TableauServer + tableauToken + "/t/" + sitename + viewName + params);
			}
		},
		complete: function (request, textStatus) {
			//alert("complete" + request.responseText);
			//alert("complete" + textStatus);
	
	
		}
	});
}

jQuery(window).resize(function () {
	window.setTimeout(function(){resizeViz();},1000);		
});

function resizeViz(){		
	
	var zoomLev = (screen.width/parseInt($('#vizContainer').find('iframe').css('width'))) ;
	/*
	zoomLev="0.95";
	$('#vizContainer').css('zoom',1);					
	$('#vizContainer').css('-ms-zoom',zoomLev);
	$('#vizContainer').css('-moz-transform', 'scale(' + zoomLev + ')');
	$('#vizContainer').css('-webkit-transform','scale(' + zoomLev + ')');			
	
	
	$('#vizContainer').find('iframe').css('zoom', 1);
	$('#vizContainer').find('iframe').css('-ms-zoom',zoomLev);
	$('#vizContainer').find('iframe').css('-moz-transform', 'scale(' + zoomLev + ')');
	$("#tabframe").find('iframe').css('-webkit-transform','scale(' + zoomLev + ')');
	viz.setFrameSize($('#vizContainer').width()+50, $('#vizContainer').height());							
	*/
			
		
}

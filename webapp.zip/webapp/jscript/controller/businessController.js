'use strict';

fcipApp.controller('businessController', function ($scope, $rootScope, accessService, $http, $uibModal, $log, $location, $routeParams, $filter, $window, $timeout, businessFactory, manualFactory, classifyService) {
    //Access Rights
    $scope.viewRights = false;
    $scope.editRights = false;
    $scope.viewRights = accessService.viewMC();
    if (!$scope.viewRights) {
      $('.vsvcui_businessControllerDeny').css('display','block');
      return;
    }
    $scope.editRights = accessService.editMC();

    var selectedRuleId = $routeParams.ruleid;

    $scope.selectedRule = {};

    $scope.selectedRuleOrg = {};

    $scope.isshowSpecificRules = 'displayAll';
    var responseOrg = {};
    $scope.loading = false;
    $scope.btn = false;
    $scope.errMsg = null;
    $scope.businessRuleAry = [];
    $scope.allBusinessRules = [];
    var coun = 0;

    var isSetLocalStorage = localStorage.getItem('businessRule');

    // To get list of business rule.
    function getDefaultRules() {
        if (businessFactory.getBusinessRulesList().length > 0 && !isSetLocalStorage) {
            let response = {
                data: businessFactory.getBusinessRulesList()
            };
            responseOrg = angular.copy(response);
            responseHandler(response, $scope.isshowSpecificRules);
            $timeout(function() {
              $('.vsvcui_businessController').css('display','block');
            }, 500);
        } else {
            if(isSetLocalStorage) {
                localStorage.removeItem('businessRule');
            }
            $scope.loading = true;
            businessFactory.getBusinessRules().then(
                function (response) {
                    responseOrg = angular.copy(response);
                    responseHandler(response, $scope.isshowSpecificRules);
                    $scope.loading = false;
                    $('.vsvcui_businessController').css('display','block');
                },
                function (response) {
                    $scope.loading = false;
                }
            );
        }

    };


    function responseHandler(response, loadSpecificRules) {
        var curData = response.data;

        if (selectedRuleId) {
            selectedRuleId = selectedRuleId.toString();
            var indexOfRule = curData.map(function (rule) { return rule.rule_id }).indexOf(selectedRuleId);
            if (indexOfRule > -1) {
                $scope.selectedRule = {};
                $scope.selectedRule = angular.copy(curData[indexOfRule]);
                $scope.business_rule_org = curData[indexOfRule].business_rule;
                $scope.selectedRule.taxonomy_codeNDescription = $scope.selectedRule.taxonomy_code + ' - ' + $scope.selectedRule.taxonomy_description;
                $scope.selectedRuleOrg = angular.copy(curData[indexOfRule]);
                $scope.selectedRuleOrg.taxonomy_codeNDescription = $scope.selectedRuleOrg.taxonomy_code + ' - ' + $scope.selectedRuleOrg.taxonomy_description;

            }
        } else {
                $scope.selectedRule.pre_classified_overwrite = "Y";
                $scope.selectedRule.creator = "Kumar"; //SHOULD LINK UP WITH LOGIN USER
                $scope.selectedRule.owner = "Kumar"; //SHOULD LINK UP WITH LOGIN USER
        }

        if(loadSpecificRules !== 'displayAll') {

            if(loadSpecificRules === 'active' || loadSpecificRules === 'inactive') {
                var activeOfRule = loadSpecificRules === 'active' ? 'Y' : 'N';
                curData = curData.filter(function (item) {
                    return item.is_active === activeOfRule;
                });
            }
        }

        $scope.total = curData.length;
        $scope.ruleId = curData[curData.length - 1];
        curData.sort(function (a, b) {
            return parseInt(a.rule_id) - parseInt(b.rule_id);
        });

        $scope.allBusinessRules = angular.copy(curData);
        $scope.loadMore = function () {
            if (coun < curData.length) {
                var currentCoun = coun;
                var len2 = 0;
                if (curData.length >= currentCoun + 10) {
                    len2 = currentCoun + 10;
                } else {
                    len2 = curData.length;
                }
                for (var j = coun; j < len2; j++) {
                    $scope.msgloading = true;
                    $scope.businessRuleAry.push(curData[coun]);
                    coun = coun + 1;
                }

            }
        }

        $scope.bottomFunction = function() {
          $scope.businessRuleAry = curData;
          coun = curData.length;
          $timeout(function() {
            document.body.scrollTop = document.body.scrollHeight;
            document.documentElement.scrollTop = document.documentElement.scrollHeight;
          }, 50);
        };

        businessFactory.setBusinessRulesList(response.data);
        $scope.loadMore();
    };

    function errMsgFn(stringmsg) {
        var err_message = "";
        if (stringmsg.indexOf("ORA-00904") >= 0) {
            err_message = "Invalid Identifier, Please check the syntax and try again.";
        } else if (stringmsg.indexOf("ORA-00920") >= 0) {
            err_message = "Invalid relational operator, Please check the syntax and try again.";
        } else if (stringmsg.indexOf("ORA-00933") >= 0) {
            err_message = "SQL Comment not properly ended. Please check the syntax and try again.";
        } else if (stringmsg.indexOf("ORA-01756") >= 0) {
            err_message = "Quoted string not properly terminated. Please check the syntax and try again.";
        }
            else{

                err_message = "Please check the syntax and try again";
            }
        return err_message;
    }

    $scope.addtaxonomy_code = undefined;
    $scope.taxloading = false;
    // To get list of taxonomy to suggest in add and edit business rule page.
    function getTaxonomy() {
        $scope.taxonomy_codes = [];
        $scope.allTaxonomy = [];
        let taxonomyList = classifyService.getTaxonomy();
        if (taxonomyList.length > 0) {
            angular.forEach(taxonomyList, function (value) {
                $scope.allTaxonomy.push(value);
                $scope.taxonomy_codes.push(value.code);
            });
        } else {
            $scope.taxloading = true;
            manualFactory.getTaxonomy().then(
                function (response) {
                    //assign value
                    angular.forEach(response.data, function (value) {
                        $scope.allTaxonomy.push(value);
                        $scope.allTaxonomy.push(value);
                        $scope.taxonomy_codes.push(value.code);
                        $scope.taxloading = false;
                    });
                    classifyService.setTaxonomy(response.data);
                },
                function (response) {
                    $scope.taxloading = false;
                    console.log(response);
                }
            );
        }
    }


    $scope.onSelectFn = function ($item, $model, $label) {
        for (var i = 0; i < $scope.allTaxonomy.length; i++) {
            if ($scope.allTaxonomy[i].code == $item.code) {
                $scope.selectedRule.taxonomy_code = $scope.allTaxonomy[i].code;
                $scope.selectedRule.taxonomy_description = $scope.allTaxonomy[i].description;
                return;
            }
        }
    };

    $scope.search_in_taxonomy_codes = function(keyword) {
        console.log($filter('filter')($scope.allTaxonomy , {'$': keyword}));
        return $filter('filter')($scope.allTaxonomy , {'$': keyword});
    }

    getTaxonomy();
    getDefaultRules();

    // Redirect to add business rule page when we clicked "add new" button in business rule page.
    $scope.addBusinesPageFn = function () {
        $location.path('/addbusinessrule');
        if (!$scope.editRights) {
          $('.vsvcui_businessControllerDeny').css('display','block');
        } else {
          $timeout(function(){
            $('.vsvcui_businessController').css('display','block');
          }, 500);
        }
    }


    //Show Delete Rules
    $scope.showSpecificRules = function () {
        $scope.businessRuleAry = [];
        coun = 0;
        responseHandler(responseOrg, $scope.isshowSpecificRules);
    }



    // To add business rule to backend
    $scope.addBusinessRuleFn = function () {
        businessFactory.addBusinessRule($scope.selectedRule).then(
            function (response) {
                if (response.data == '1' || response.data == '0') //Show add succesfully only when response from service is 0
                {
                    localStorage.setItem('businessRule', {'ruleAction': 'add', rule: null});
                    // SUCCESS POPUP, GO BACK TO MAIN PAGE
                    $scope.open('success', 'Business', 'Rule added successfully', 'myModalContentSuccess');

                } else {
                    var err_message_popup = errMsgFn(response.data);
                    $scope.open('danger', 'business', err_message_popup);
                    // ERROR POPUP
                }
            },
            function (response) {
                var err_message_popup = errMsgFn(response);
                $scope.open('danger', 'business', err_message_popup);
            }
        );
    }

    $scope.successOk = function () {
        $location.path('/businessrules');
    }


    //To reset edit business rule page
    $scope.resetBusinessRuleFn = function (form) {
        $scope.selectedRule = angular.copy($scope.selectedRuleOrg);
        form.$setPristine();
    }

    // when we click edit business rule link to list particular rule id information.
    $scope.editBusinessRuleFn = function (businessObj) {
        if (businessObj && businessObj.rule_id) {
            $location.path('/businessrules/' + businessObj.rule_id);
            if (!$scope.editRights) {
              $('.vsvcui_businessControllerDeny').css('display','block');
            } else {
              $timeout(function(){
                $('.vsvcui_businessController').css('display','block');
              }, 500);
            }
            return;
        }
    }

    // To updated business rule to backend.
    $scope.updateBusinessRuleFn = function (isActive) {
        if (isActive) {
            $scope.selectedRule.is_active = 'Y';
        }

        businessFactory.updateBusinessRule($scope.selectedRule).then(
            function (response) {
                if (response.data == '1' || response.data == '0') {
                    localStorage.setItem('businessRule', {'ruleAction': 'update', rule: $scope.selectedRule});
                    // SUCESS POPUP, RETURN TO MAIN PAGE
                    $scope.open('success', 'Business', 'Rule updated successfully', 'myModalContentSuccess');

                } else {
                    // ERROR POPUP
                    var err_message_popup = errMsgFn(response.data);
                    $scope.open('danger', err_message_popup);
                }
            },
            function (response) {
                var err_message_popup = errMsgFn(response);
                $scope.open('danger', 'business', err_message_popup);
            }
        );
    }


    //To delete business rule.
    $scope.deleteBusinessRuleFn = function (id) {
        $scope.rulesObj = {};
        $scope.rulesObj.rule_id = parseInt(id);
        $scope.rulesObj.modified_by = currentlyLoginUser;
        $scope.rulesObj.comments = $scope.selectedRule.comments;
        businessFactory.deleteBusinessRule($scope.rulesObj).then(
            function (response) {
                localStorage.setItem('businessRule', {'ruleAction': 'delete', rule: $scope.selectedRule});
                $scope.open('success', 'Business', 'Rule deleted successfully', 'myModalContentSuccess');

            },
            function (response) {
                $scope.open('danger', 'Error', 'Can`t able to Delete Rule');
            }
        );
    }

     //To Reactivate Business Rule
    $scope.recreateRule =  function () {
        $scope.rulesObj = {};
        $scope.rulesObj.rule_id = $scope.selectedRule.rule_id;
        $scope.rulesObj.modified_by = currentlyLoginUser; // Need to map with maodified_by
        $scope.rulesObj.comments = $scope.selectedRule.comments;
        businessFactory.recreationBusinessRule($scope.rulesObj).then(
            function (response) {
                localStorage.setItem('businessRule', {'ruleAction': 'recreation', rule: $scope.selectedRule});
                $scope.open('success', 'Business', 'Rule Reactivated Successfully', 'myModalContentSuccess');

            },
            function (response) {
                $scope.open('danger', 'Error', 'Unable to Reactivate Rule');
            }
        );
    }


    function formatDate(date){
        return ("0" + (date.getMonth() + 1)).slice(-2).toString() + ("0" + date.getDate()).slice(-2).toString() + date.getFullYear().toString();
    }
    
    function formatTimeAMPM(date) {
      var hours = date.getHours();
      var minutes = date.getMinutes();
      var ampm = hours >= 12 ? 'pm' : 'am';
      hours = hours % 12;
      hours = hours ? hours : 12; // the hour '0' should be '12'
      minutes = minutes < 10 ? '0'+minutes : minutes;
      var strTime = '_' + ("0" + hours).slice(-2) + '_' + minutes + '_' + ("0" + date.getSeconds()).slice(-2) + ampm.toUpperCase();
      return strTime;
    }
    
    function makeList(list){
        var tempList = [];
        angular.forEach(list,function(value){
            var temp = {};
            temp.rule_id = value.rule_id;
            temp.business_rule = value.business_rule;
            temp.taxonomy_code = value.taxonomy_code;
            temp.taxonomy_description = value.taxonomy_description;
            temp.category = value.category;
            temp.priority = value.priority;
            temp.complexity = value.complexity;
            temp.creator = value.creator;
            temp.owner = value.owner;
            temp.record_insert_datetime = value.record_insert_datetime;
            temp.pre_classified_overwrite = value.pre_classified_overwrite;
            temp.created_date = value.created_date;
            temp.modified_date = value.modified_date;
            temp.created_by = value.created_by;
            temp.modified_by = value.modified_by;
            temp.comments = value.comments;
            temp.is_active = value.is_active;
            tempList.push(temp);
        });
        return tempList;
    }
    
    $scope.downloadFile = function () {
        if($scope.businessRuleAry.length == 0 && $scope.search){
            var tempList = [{"rule_id":"","business_rule":"","taxonomy_code":"","taxonomy_description":"","category":"","priority":"","complexity":"","creator":"","owner":"","record_insert_datetime":"","pre_classified_overwrite":"","created_date":"","modified_date":"","created_by":"","modified_by":"","comments":"","is_active":""}];
            var fileName = 'Businessrules_' + $scope.search + '_' + formatDate(new Date()) + formatTimeAMPM(new Date()) +'.xlsx';
            alasql('SELECT * INTO XLSX("' + fileName + '",{headers:true}) FROM ?',[tempList]);   
        }
        else if($scope.businessRuleAry.length > 0 && $scope.search){
            var fileName = 'Businessrules_' + $scope.search + '_' + formatDate(new Date()) + formatTimeAMPM(new Date()) +'.xlsx';
            alasql('SELECT * INTO XLSX("' + fileName + '",{headers:true}) FROM ?',[makeList($scope.businessRuleAry)]);   
        }
        else{
            var fileName = 'Businessrules_' + formatDate(new Date()) + formatTimeAMPM(new Date()) +'.xlsx';
            alasql('SELECT * INTO XLSX("' + fileName + '",{headers:true}) FROM ?',[makeList($scope.allBusinessRules)]);
        }
    };


    $scope.complexity = [
        'Simple',
        'Medium',
        'High',
    ];

    $scope.preClassified = [
        'Y',
        'N',
    ];

    $scope.selectRightItem = function (item) {
        $scope.pre_classified_overwrite = item ? item : 'Select Pre Classified Overwrite';
    };

    window.onscroll = function () {
        scrollFunction()
    };

    function scrollFunction() {
        if (document.getElementById("myBtn") || document.getElementById("myBtn1")) {
            if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
                document.getElementById("myBtn").style.display = "block";
                document.getElementById("myBtnDown").style.display = "block";
            } else {
                document.getElementById("myBtn").style.display = "none";
                document.getElementById("myBtnDown").style.display = "none";
            }
        }
    }

    // When the user clicks on the button, scroll to the top of the document
    $scope.topFunction = function () {
        document.body.scrollTop = 0;
        document.documentElement.scrollTop = 0;
    }

   // When the user clicks on the button, scroll to the bottom of the document
    // $scope.bottomFunction = function () {
    //     var allRules = $scope.loadAll();
    //     document.body.scrollTop = document.body.scrollHeight;
    //     document.documentElement.scrollTop = document.documentElement.scrollHeight;
    // }

    $scope.open = function (mode, err_title, erro_msg, templateId) {

        $scope.items = [{
            mode: mode,
            title: err_title,
            content: erro_msg
        }];


        var modeofTemplate = templateId ? templateId : 'myModalContent';
        var modalInstance = $uibModal.open({
            templateUrl: modeofTemplate, //refers to modal content
            controller: 'modalInstanceCtrl', //inner controller
            scope: $scope, //scope elements
            ariaLabelledBy: 'modal-title',
            ariaDescribedBy: 'modal-body',
            windowClass: 'error-modal'
        });

    };

})

fcipApp.controller('modalInstanceCtrl', function ($scope, $uibModalInstance) {

    $scope.ok = function () {
        $uibModalInstance.close();
    };

    $scope.cancel = function () {
        $uibModalInstance.dismiss('cancel');
    };

});
fcipApp.directive('elastic', [
    '$timeout',
    function ($timeout) {
        return {
            restrict: 'A',
            link: function ($scope, element) {
                $timeout(function() {
                  $scope.initialHeight = $scope.initialHeight || element[0].style.height;
                  var resize = function () {
                      element[0].style.height = $scope.initialHeight;
                      element[0].style.height = "" + (parseFloat(element[0].scrollHeight) + 5).toString() + "px";
                      if (element[0].style.height == '5px') {
                        $timeout(resize, 200);
                      }
                  };
                  element.on("input change", resize);
                  $timeout(resize, 0);
                }, 200);
            }
        };
    }
]);
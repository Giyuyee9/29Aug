'use strict';

fcipApp.controller('manualController', function($window, $timeout, $scope, manualFactory, classifyService, accessService) {
  // Access Rights
  $scope.viewRights = false;
  $scope.viewRights = accessService.viewMC();
  if (!$scope.viewRights) {
    $('.vsvcui_manualControllerDeny').css('display','block');
    return;
  }
  $scope.editRights = false;
  $scope.editRights = accessService.editMC();

  // Sorting
  $scope.orderByField = 'spend';
  $scope.reverseSort = true;

  // Spinner
  $scope.loading = false;

  // Each accordion section, open all by default
  $scope.accordionOpen = [true, true, true];

  // List of records currently shown
  $scope.invoices = [];
  $scope.lastRecordGrabbed = 100;
  var allLoaded = false;

  // Record table selection
  $scope.rowSelected = false;
  $scope.numSelected = 0;
  $scope.selected = {};
  $scope.records = {'selectAllValue': false};

  // Table headers
  $scope.confHeaders = ['Range', 'Invoices', 'Spend'];
  $scope.supplierHeaders = ['Supplier', 'Percent', 'Spend'];
  $scope.ageHeaders = ['Load Date', 'Invoices', 'Percent', 'Spend'];
  $scope.dataHeaders = [
    'Supplier',
    'Invoice Description',
    'GL Account',
    'Cost Center',
    'Taxonomy',
    'Spend',
    ' '
  ];

  // Record and spend counts
  $scope.counts = {
    'srcSpend': 0,
    'srcRecords': 0,
    'manualSpend': 0,
    'manualRecords': 0,
    'filterCount': 0
  }

  // Filters
  $scope.activeFilters = [];
  $scope.sources = {
    'PS': true,
    'vSAP': true,
    'nSAP': true,
    'iSAP': true,
    'CP': true
  };
  $scope.classification = {
    'status': 'unclassified'
  };
  $scope.filters = [{
    'left': 'Select Filter',
    'mid': 'Select Comparator',
    'right': '',
    'midItems': ['equals', 'does not equal', 'contains', 'does not contain'],
    'placeholder': 'ABC'
  }];
  $scope.leftItems = [
    'Supplier Name',
    'Invoice Description',
    'GL Account Name',
    'Cost Center',
    'Spend',
    'Line Items',
    'Confidence',
    'Taxonomy Code',
    'Taxonomy Description',
    'Source Systems',
    'Classified Status',
    'Date'
  ];
  var midItemsString = [
    'equals',
    'does not equal',
    'contains',
    'does not contain'
  ];
  var midItemsNum = [
    'equals (=)',
    'does not equal (!=)',
    'is less than (<)',
    'is greater than (>)'
  ];

  // Scroll to top floater
  $scope.topFunction = function() {
    document.body.scrollTop = 0;
    document.documentElement.scrollTop = 0;
  }
	function scrollFunction() {
    if (document.getElementById("myBtn")) {
	    if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
        document.getElementById("myBtn").style.display = "block";
	    } else {
		    document.getElementById("myBtn").style.display = "none";
	    }
    }
  }

  // API: get records
  function getInvoices(end, newFilters) {
    var start = end-100;
    $scope.loading = true;

    manualFactory.getManualInvoices(start, end, $scope.filters).then(
      function(data) {
        // Check if you've already gotten the last set
        if (!allLoaded) {
          // Check if there are new filters to apply
          if (!newFilters) {
            $scope.invoices = $scope.invoices.concat(data.data);
          } else {
            $scope.invoices = data.data;
          }
          // Turn numbers into floats
          for (var i = 0; i < $scope.invoices.length; i++) {
            if (typeof $scope.invoices[i].spend != 'number') {
              $scope.invoices[i].spend = parseFloat($scope.invoices[i].spend);
              $scope.invoices[i].lineitems = parseFloat($scope.invoices[i].lineitems);
              $scope.invoices[i].confidence_level = parseFloat($scope.invoices[i].confidence_level);
            }
          }
        }
        // This is the last set
        if (data.data.length < 100) {
          allLoaded = true;
        }

        $('.vsvcui_manualController').css('display','block');
        $scope.loading = false;
      },
      function(response) {
        console.log(response);
        $('.vsvcui_manualController').css('display','block');
        $scope.loading = false;
      }
    );
  };

  // Store taxonomy for assign screen
  function cacheTaxonomy() {
    manualFactory.getTaxonomy().then(
      function(data) {
        classifyService.setTaxonomy(data.data);
      },
      function(response) {
        console.log(response);
      }
    );
  }

  // API: get the percent of spend classified
  function getSpendClassified() {
    manualFactory.getSpendClassified().then(
      function(data) {
        if (!data.data) {
          $scope.spendClassified = 0;
        } else {
          $scope.spendClassified = data.data;
        }
        // Find out how much is left to do
        $scope.spendLeft = $scope.counts.srcSpend * ((99.5 - $scope.spendClassified) * 0.01);
      },
      function(response) {
        console.log(response);
      }
    );
  }

  // API: get the total count of records and spend
  function getTotalCount() {
    manualFactory.getTotalCount().then(
      function(data) {
        $scope.counts.srcSpend = data.data[0].SPEND;
        $scope.counts.srcRecords = data.data[0].TOTAL_RECORDS;
      },
      function(response) {
        console.log(response);
      }
    );
  }

  // API: get the count of records and spend that need to be classified
  function getManualCount() {
    manualFactory.getManualCount().then(
      function(data) {
        $scope.counts.manualSpend = data.data[0].SPEND;
        $scope.counts.manualRecords = data.data[0].TOTAL_RECORDS;
      },
      function(response) {
        console.log(response);
      }
    );
  }

  // API: get the count of records with the applied filters
  function getFilteredCount(haveFilters, filters) {
    manualFactory.getFilteredCount(haveFilters, filters).then(
      function(data) {
        $scope.counts.filterCount = data.data[0].TOTAL_RECORDS;
      },
      function(response) {
        console.log(response);
      }
    );
  }

  // API: get the confidence level summary table
  function getConfidences() {
    manualFactory.getConfidenceLevels().then(
      function(data) {
        $scope.confs = [];
        // Sort the table
        for (var i=0; i<data.data.length; i++) {
          // Null values are really 0
          if (data.data[i].spend == null) {
            data.data[i].spend = 0;
          }
          switch (data.data[i].range) {
            case '0-33%':
              $scope.confs[0] = data.data[i];
              break;
            case '34-66%':
              $scope.confs[1] = data.data[i];
              break;
            case '67-99%':
              $scope.confs[2] = data.data[i];
              break;
            case '100% (Classified)':
              $scope.confs[3] = data.data[i];
              break;
            case 'Total':
              $scope.confs[4] = data.data[i];
              break;
          }
        }
      },
      function(response) {
        console.log(response);
      }
    );
  };

  // API: get the top suppliers summary table
  function getTopSuppliers() {
    manualFactory.getTopSuppliers().then(
      function(data) {
        var totalSpend, totalIndex;
        // Get the total spend
        for (var i=0; i<data.data.length; i++) {
          if (data.data[i].supplier_name == 'Total') {
            totalSpend = data.data[i].spend;
            totalIndex = i;
          }
        }

        // Remove the total row
        data.data.splice(totalIndex, 1);

        // Get the percentage of spend for each supplier
        for (var i=0; i<data.data.length; i++) {
          data.data[i].percent = data.data[i].spend / totalSpend * 100;
        }
        // Sort the table by spend
        data.data.sort(function(a, b) {
            return parseFloat(b.spend) - parseFloat(a.spend);
        });

        $scope.topSuppliers = data.data;
      },
      function(response) {
        console.log(response);
      }
    );
  };

  // API: get the spend percentage summary table
  // $scope.spendHeaders = ['Invoices', 'Percent', 'Spend'];
  //
  // function getSpendPercents() {
  //   manualFactory.getSpendPercentages().then(
  //     function(data) {
  //       $scope.spendPercents = [];
  //       var totalSpend;
  //       for (var i=0; i<data.data.length; i++) {
  //         if (data.data[i].spend == null) {
  //           data.data[i].spend = 0;
  //         } else {
  //           data.data[i].spend = parseFloat(data.data[i].spend);
  //         }
  //         switch (data.data[i].invoices) {
  //           case 'Unclassified-Top 100':
  //             $scope.spendPercents[0] = data.data[i];
  //             break;
  //           case 'Unclassified-Rest':
  //             $scope.spendPercents[1] = data.data[i];
  //             break;
  //           case 'Classified-Top 100':
  //             $scope.spendPercents[2] = data.data[i];
  //             break;
  //           case 'Classified-Rest':
  //             $scope.spendPercents[3] = data.data[i];
  //             break;
  //           case 'Total':
  //             $scope.spendPercents[4] = data.data[i];
  //             totalSpend = data.data[i].spend;
  //             break;
  //         }
  //       }
  //
  //       for (var i=0; i<$scope.spendPercents.length; i++) {
  //         if (i == $scope.spendPercents.length-1) {
  //           $scope.spendPercents[i].percent = 100;
  //         } else {
  //           $scope.spendPercents[i].percent = $scope.spendPercents[i].spend / totalSpend * 100;
  //         }
  //       }
  //     },
  //     function(response) {
  //       console.log(response);
  //     }
  //   );
  // };

  // API: get the classification level summary table
  // $scope.taxHeaders = ['Classification', 'Invoices', 'Spend'];
  //
  // function getClassifications() {
  //   manualFactory.getClassificationLevels().then(
  //     function(data) {
  //       $scope.taxs = data.data;
  //     },
  //     function(response) {
  //       console.log(response);
  //     }
  //   );
  // };
  // getClassifications();

  // API: get the aging summary table
  function getAges() {
    manualFactory.getAging().then(
      function(data) {
        var older, total;
        var olderIndex, totalIndex;

        for (var i=0; i<data.data.length; i++) {
          // Turn nulls into 0s
          if (data.data[i].invoices == null) {
            data.data[i].invoices = 0;
          }
          if (data.data[i].spend == null) {
            data.data[i].spend = 0;
          }
          // Get the 'older' row
          if (data.data[i].load_date == 'Older') {
            older = data.data[i];
            olderIndex = i;
          }
          // Get the total row
          if (data.data[i].load_date == 'Total') {
            total = data.data[i];
            if (i == data.data.length-1) {
              totalIndex = -1;
            } else {
              totalIndex = i;
            }
          }
        }

        // Remove the older and total rows
        data.data.splice(olderIndex, 1);
        data.data.splice(totalIndex, 1);

        // Sort the dates
        data.data.sort(function(a, b) {
          a = a.load_date.split('/').reverse();
          a = a[0] + '' + a[2] + '' + a[1];
          b = b.load_date.split('/').reverse();
          b = b[0] + '' + b[2] + '' + b[1];
          return a > b ? 1 : a < b ? -1 : 0;
        });

        // Put the older and total rows back where we want
        data.data.unshift(older);
        data.data.push(total);

        // Get the spend percentages
        for (var i=0; i<data.data.length; i++) {
          data.data[i].percent = data.data[i].spend / total.spend * 100;
        }

        $scope.ages = data.data;
      },
      function(response) {
        console.log(response);
      }
    );
  };

  // Filter based on the confidence level summary table
  $scope.confFilter = function(range) {
    var low, high;
    // Get the confidence range wanted
    switch (range) {
      case '0-33%':
        low = 0;
        high = 33;
        break;
      case '34-66%':
        low = 34;
        high = 66;
        break;
      case '67-99%':
        low = 67;
        high = 99;
        break;
      // Unique case, records must already be classified
      case '100% (Classified)':
        // Make the 100% confidence filter
        var hundredFilter = {
          'left': 'Confidence',
          'mid': 'equals (=)',
          'right': 100
        };
        // Make the classified records filter
        var classifyFilter = {
          'left': 'Classified Status',
          'mid': 'classified',
          'right': 'records'
        };

        // Reset filters, apply our new ones
        $scope.classification.status = 'classified';
        $scope.filters = [];
        $scope.activeFilters = [];
        $scope.filters.push(classifyFilter);
        $scope.addActiveFilter(classifyFilter, 0);
        $scope.filters.push(hundredFilter);
        $scope.addActiveFilter(hundredFilter, 1);
        $scope.addFilter();
        classifyService.setFilters($scope.filters);

        allLoaded = false;
        $scope.lastRecordGrabbed = 100;
        getFilteredCount(true, $scope.filters);
        getInvoices($scope.lastRecordGrabbed, true);

        return;
      // Don't do anything for total
      case 'Total':
        return;
    }

    // Make the filters based on confidences wanted
    var lowFilter = {
      'left': 'Confidence',
      'mid': 'is greater than (>)',
      'right': low-1
    };

    var highFilter = {
      'left': 'Confidence',
      'mid': 'is less than (<)',
      'right': high+1
    };

    // Reset filters, apply our new ones
    $scope.classification.status = 'unclassified';
    $scope.filters = [];
    $scope.activeFilters = [];
    $scope.filters.push(lowFilter);
    $scope.addActiveFilter(lowFilter, 0);
    $scope.filters.push(highFilter);
    $scope.addActiveFilter(highFilter, 1);
    $scope.addFilter();
    classifyService.setFilters($scope.filters);

    allLoaded = false;
    $scope.lastRecordGrabbed = 100;
    getFilteredCount(true, $scope.filters);
    getInvoices($scope.lastRecordGrabbed, true);
  };

  // Filter based on the spend percentage summary table
  // $scope.spendFilter = function(invoices) {
  //   switch (invoices) {
  //     case 'Unclassified-Top 100':
  //       $scope.resetFilters(true);
  //       break;
  //     case 'Unclassified-Rest':
  //       $scope.resetFilters(false);
  //       $scope.lastRecordGrabbed = 200;
  //       getFilteredCount(false, null);
  //       getInvoices($scope.lastRecordGrabbed, true);
  //       break;
  //     case 'Classified-Top 100':
  //       var filter = {
  //         'left': 'Classified Status',
  //         'mid': 'classified',
  //         'right': 'records',
  //       };
  //
  //       $scope.classification.status = 'classified';
  //       $scope.filters = [];
  //       $scope.activeFilters = [];
  //       $scope.filters.push(filter);
  //       $scope.addActiveFilter(filter, 0);
  //       $scope.addFilter();
  //       classifyService.setFilters($scope.filters);
  //
  //       allLoaded = false;
  //       $scope.lastRecordGrabbed = 100;
  //       getFilteredCount(true, $scope.filters);
  //       getInvoices($scope.lastRecordGrabbed, true);
  //       break;
  //     case 'Classified-Rest':
  //     var filter = {
  //       'left': 'Classified Status',
  //       'mid': 'classified',
  //       'right': 'records',
  //     };
  //
  //     $scope.classification.status = 'classified';
  //     $scope.filters = [];
  //     $scope.activeFilters = [];
  //     $scope.filters.push(filter);
  //     $scope.addActiveFilter(filter, 0);
  //     $scope.addFilter();
  //     classifyService.setFilters($scope.filters);
  //
  //     allLoaded = false;
  //     $scope.lastRecordGrabbed = 200;
  //     getFilteredCount(true, $scope.filters);
  //     getInvoices($scope.lastRecordGrabbed, true);
  //     break;
  //   }
  // };

  // Filter based on the top suppliers summary table
  $scope.supplierFilter = function(name) {
    // Make a 'supplier name = ' filter
    var filter = {
      'left': 'Supplier Name',
      'mid': 'equals',
      'right': name
    };

    // Reset filters, apply our new ones
    $scope.classification.status = 'unclassified';
    $scope.filters = [];
    $scope.activeFilters = [];
    $scope.filters.push(filter);
    $scope.addActiveFilter(filter, 0);
    $scope.addFilter();
    classifyService.setFilters($scope.filters);

    allLoaded = false;
    $scope.lastRecordGrabbed = 100;
    getFilteredCount(true, $scope.filters);
    getInvoices($scope.lastRecordGrabbed, true);
  };

  // Filter based on the aging summary table
  $scope.ageFilter = function(age) {
    // Don't do anything for total or older rows
    if (age == 'Total' || age == 'Older') {
      return;
    }

    // Make a date filter, same from and to dates
    var filter = {
      'left': 'Date',
      'mid': 'from ',
      'right': age + ' to ' + age,
      'start': age,
      'end': age
    };

    // Reset filters, apply our new ones
    $scope.classification.status = 'unclassified';
    $scope.filters = [];
    $scope.activeFilters = [];
    $scope.filters.push(filter);
    $scope.addActiveFilter(filter, 0);
    $scope.addFilter();
    classifyService.setFilters($scope.filters);

    allLoaded = false;
    $scope.lastRecordGrabbed = 100;
    getFilteredCount(true, $scope.filters);
    getInvoices($scope.lastRecordGrabbed, true);
  };

  // Classify the selected rows using the suggestions given
  $scope.acceptSuggestions = function() {
    $scope.loading = true;
    var invoicesAccepted = [];
    // Only take records that have been selected and have a suggestion
    for (var i=0; i<$scope.invoices.length; i++) {
      if ($scope.selected[$scope.invoices[i].seq_id] && $scope.invoices[i].suggested_taxonomy_code != null) {
        invoicesAccepted.push($scope.invoices[i]);
      }
    }

    // No suggestions given, inform user
    if (invoicesAccepted.length == 0) {
      $scope.loading = false;
      $scope.toastMsg = 'Cannot accept a nonexistant suggestion';
      $scope.toastTrigger = 1;
      $timeout(function() {
        $scope.toastTrigger = 0;
      }, 3000);
      return;
    }

    // API: classify the invoices
    manualFactory.submitBySuggestion(invoicesAccepted).then(
      function(data) {
        // Update records and counts
        $scope.updateFilter();
        getSpendClassified();
        getConfidences();
        getTopSuppliers();
        getAges();
        $scope.selectAll(false);

        // Tell the user
        if (invoicesAccepted.length == 1) {
          $scope.toastMsg = 'Classified 1 Record';
        } else {
          $scope.toastMsg = 'Classified ' + invoicesAccepted.length + ' Records';
        }
        $scope.toastTrigger = 1;
        $timeout(function() {
            $scope.toastTrigger = 0;
        }, 3000);
      },
      function(response) {
        console.log(response);
        $scope.loading = false;
      }
    );
  };

  // API: flag the classified records to be sent to data lake and truncated
  $scope.submitFinal = function() {
    $scope.loading = true;
    manualFactory.submitFinal().then(
      function(data) {
        $scope.loading = false;
        $scope.toastMsg = 'Successfully Committed Classifications';
        $scope.toastTrigger = 1;
        $timeout(function() {
          $scope.toastTrigger = 0;
        }, 3000);
      },
      function(response) {
        console.log(response);
        $scope.loading = false;
      }
    );
  }

  // Filter functions
  // Change the middle dropdown and placeholder based on the left dropdown
  $scope.selectLeftItem = function(filter, item, index) {
    filter.left = item;
    if (filter.left == 'Spend' || filter.left == 'Line Items' || filter.left == 'Confidence') {
      filter.midItems = midItemsNum;
      filter.placeholder = '123';
    } else {
      filter.midItems = midItemsString;
      filter.placeholder = 'ABC';
    }
    // Reset middle and right selections in case type was changed
    filter.mid = 'Select Comparator';
    filter.right = '';
  };

  // Select the comparator for this filter
  $scope.selectMidItem = function(filter, item, index) {
    filter.mid = item;
  };

  // Remove a filter
  $scope.removeFilter = function(filter, index) {
    $scope.filters.splice(index, 1);
    $scope.activeFilters.splice(index, 1);
    if ($scope.filters.length == 0) {
      $scope.resetFilters(true);
    }
  };

  // Apply the current filter selection
  $scope.updateFilter = function() {
    // We no longer have all matching records
    allLoaded = false;
    // Format filters to display in the Filters Applied box
    for (var i = 0; i < $scope.filters.length; i++) {
      if ($scope.filters[i].left == 'Date') {
        $scope.filters[i].mid = 'from ';
        $scope.filters[i].right = $scope.filters[i].start + ' to ' + $scope.filters[i].end;
      } else if ($scope.filters[i].left == 'Source Systems') {
        $scope.filters[i].mid = '';
        $scope.filters[i].sources = [];
        for (var source in $scope.sources) {
          if ($scope.sources[source]) {
            $scope.filters[i].mid += source + ', ';
            $scope.filters[i].sources = $scope.filters[i].sources.concat(source);
          }
        }
        // Remove final comma and space
        $scope.filters[i].mid = $scope.filters[i].mid.substring(0, $scope.filters[i].mid.length-2);
        // Fill in filter.right so it will display
        $scope.filters[i].right = 'SOURCES';
      } else if ($scope.filters[i].left == 'Classified Status') {
        $scope.filters[i].mid = $scope.classification.status;
        $scope.filters[i].right = 'records';
      }
      // Add the filter to the Filters Applied box
      $scope.addActiveFilter($scope.filters[i], i);
    }
    // Update filter count
    getFilteredCount(true, $scope.filters);
    classifyService.setFilters($scope.filters);

    // Deselect everything
    $scope.selectAll(false);
    $scope.records.selectAllValue = false;

    // Get the new set of records
    $scope.lastRecordGrabbed = 100;
    getInvoices($scope.lastRecordGrabbed, true);
  };

  // Check if we can enable the Apply button
  $scope.disableUpdateFilter = function() {
    for (var i = 0; i < $scope.filters.length; i++) {
      if ($scope.filters[i].left == 'Date') {
        if ($scope.filters[i].start == null || $scope.filters[i].end == null) {
          return 'in-active';
        } else {
          continue;
        }
      }

      // Any entry is valid for source systems and classified status
      if ($scope.filters[i].left == 'Source Systems') {
        continue;
      }

      if ($scope.filters[i].left == 'Classified Status') {
        continue;
      }

      if ($scope.filters[i].right == '' || $scope.filters[i].left == "Select Filter" || $scope.filters[i].mid == 'Select Comparator') {
        return 'in-active';
      }
    }
    return '';
  };

  // Add a filter to the Filters Applied box
  $scope.addActiveFilter = function(filter, index) {
    if (filter.left && filter.mid && filter.right && filter.left != "Select Filter" && filter.mid != 'Select Comparator') {
      $scope.activeFilters[index] = angular.copy(filter);
    }
  };

  // Add a new, empty filter to the filters section
  $scope.addFilter = function() {
    $scope.filters.push({
      "left": 'Select Filter',
      "mid": 'Select Comparator',
      right: '',
      "midItems": ['equals', 'does not equal', 'contains', 'does not contain'],
      "placeholder": 'ABC'
    });
  };

  // Remove all filters, add one empty one
  $scope.resetFilters = function(fetch) {
    $scope.activeFilters = [];
    $scope.filters = [{
      "left": 'Select Filter',
      "mid": 'Select Comparator',
      "right": '',
      "midItems": ['equals', 'does not equal', 'contains', 'does not contain'],
      "placeholder": 'ABC'
    }];

    // Delete the filter cache
    classifyService.setFilters($scope.filters);

    // Set default sorting
    $scope.classification.status = 'unclassified';
    $scope.orderByField = 'spend';
    $scope.reverseSort = true;

    // Deselect everything
    $scope.selectAll(false);
    $scope.records.selectAllValue = false;

    // Check if we need to get new records
    if (fetch) {
      $scope.invoices = [];
      $scope.lastRecordGrabbed = 100;
      allLoaded = false;
      getInvoices($scope.lastRecordGrabbed, true);
      getFilteredCount(false, null)
    }
  };

  // Select (deselect) all records in the table
  $scope.selectAll = function(toggle) {
    toggle = parseFloat(toggle);

    for (var i = 0; i < $scope.invoices.length; i++) {
      var invoice = $scope.invoices[i];
      if (toggle) {
        $scope.rowSelected = true;
        $scope.numSelected = $scope.invoices.length;
        if (!$scope.selected[invoice.seq_id]) {
          $scope.selected[invoice.seq_id] = true;
        }
      } else {
        $scope.rowSelected = false;
        $scope.numSelected = 0;
        if ($scope.selected[invoice.seq_id]) {
          $scope.selected[invoice.seq_id] = false;
        }
      }
    }
  };

  // Select (deselect) a single record in the table and increment (decrement) count
  $scope.toggleSelected = function(invoice) {
    if ($scope.selected[invoice.seq_id]) {
      $scope.selected[invoice.seq_id] = false;
      $scope.numSelected--;
    } else {
      $scope.selected[invoice.seq_id] = true;
      $scope.numSelected++;
    }

    // Update Change Classification button
    checkAnySelected();
  };

  // Check if any rows are selected to enable Change Classification button
  function checkAnySelected() {
    for (var invoice in $scope.selected) {
      if ($scope.selected[invoice] == true) {
        $scope.rowSelected = true;
        return;
      }
    }

    $scope.rowSelected = false;
  }

  // Cache the invoices to classify to move to the assign screen
  $scope.sendInvoices = function() {
    var toClassify = [];
    for (var i = 0; i < $scope.invoices.length; i++) {
      if ($scope.selected[$scope.invoices[i].seq_id] == true) {
        toClassify.push($scope.invoices[i]);
      }
    }

    classifyService.setInvoices(toClassify);
  };

  // API: Get the next set of records
  $scope.loadMore = function() {
    $scope.lastRecordGrabbed += 100;
    getInvoices($scope.lastRecordGrabbed, false);
  };

  // Call needed APIs on page load
  function initalServiceCalls() {
    getInvoices($scope.lastRecordGrabbed, true);
    getSpendClassified();
    cacheTaxonomy();
    getTotalCount();
    getManualCount();
    getFilteredCount(false, null);
    classifyService.setFilters($scope.filters);
    getConfidences();
    getTopSuppliers();
    getAges();
  }

  initalServiceCalls();
}); //End manual controller

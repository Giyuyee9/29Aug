'use strict';

function ThumbnailViewModel(workbook,token,http) {		
	
	var self = this;
	self.ModelName = "Thumbnails";			
	self.WorkBookId = workbook.workbookId;
	self.WorkBookName = workbook.workbookName;
	self.ProjectId = workbook.projectId;
	self.ProjectName = workbook.projectName;
	self.SRC = getBase64Img(workbook.workbookId,workbook.url,token,http);	
	self.ViewURL = getViewURL(workbook.workbookId,workbook.workbookName,http);	
}

function getViewURL(workbookId, workbookName, http){
	
	http({
		method: 'POST',
		url: document.getElementById('tableauSvc').value+'Tableau/getViewsForWorkBook',
		headers: {'Content-Type':'application/json'},
		data: {"workbookId" : workbookId} 
	}).success(function(response){				
		for (var i=0;i<1;i++) {												
			if (document.getElementById('a_' +workbookId) != null && response != "" && response != null) {					
				document.getElementById('a_' +workbookId).href = "#/tableau/" + workbookName + "/FinanceCIP/" + response[i].contentUrl.split('/')[0] + '|' + response[i].contentUrl.split('/')[2];
			}
		}						
	}).error(function(response){						
		document.getElementById('a_' +workbookid).href = "";
	});
}

function getBase64Img(workbookid, preview, token,http){
	http({
		method: 'POST',
		url: document.getElementById('tableauSvc').value+'Tableau/getPreviewImageBase64',
		headers: {'Content-Type':'application/json'},
		data: {"url" : preview} 
	}).success(function(response){				
		var arrayBuffer = response;				
		var mimetype="image/png"; // or whatever your image mime type is						
		if (document.getElementById('img_' +workbookid) != null) {
			document.getElementById('img_' +workbookid).src = "data:"+mimetype+";base64,"+response;						
		}			
	}).error(function(response){						
		document.getElementById('a_' +workbookid).href = "";
	});
}
	
fcipApp.controller('dashboardListController',function($scope,$rootScope,$routeParams, $http) {
	
	$rootScope.navpagname = "Home";
	$rootScope.navpagnameURL = "#";
	$rootScope.pagenameURL = "#/dashboardList/" + $routeParams.menu + "/" + $routeParams.project;	
	$rootScope.pagename = $routeParams.menu;	
	$scope.project = $routeParams.project;	
	var siteID = $routeParams.sitename;
	
	if($rootScope.project !=="null"){
		$scope.progressLbl=false;
		$http({
			method: 'POST',
			url: document.getElementById('tableauSvc').value+'Tableau/getThumbnail',
			headers: {'Content-Type':'application/json'},
			data: {"userName" : uVZID, "siteName" : siteID} 
		}).success(function(response){	
			var respData = response;						
			var thumbNailList=[];			
			for (var i=0;i<	response.workbookThumbnail.length;i++) {													
				var wb = respData.workbookThumbnail[i];				
				var tb = new ThumbnailViewModel(wb,respData.token,$http);
				thumbNailList.push(tb);				
			}			
			$scope.thumbNails = thumbNailList;				
			$scope.progressLbl=false;
			/*for (var i=0;i<	respData.workbookThumbnail.length;i++) {				
				getBase64Img(respData.workbookThumbnail[i].workbookId,respData.workbookThumbnail[i].url,respData.token);
			}*/
			
		}).error(function(response){
			$scope.progressLbl=false;
		});
	}
	
});/* end of dashboardListController */


fcipApp.controller('dashboardListControllerNew',function($scope,$rootScope,$routeParams, $http,$sce,$compile) {			
	/*var shtml = loadTemplate($http,'https://fcipwidgetservice-dev.cfappstdcnpz1.ebiz.verizon.com/FCIPWidget/getContentByKey?key=FCIP_NGROUTE_DASHBOARDLIST');		
	$scope.template =  $sce.trustAsHtml(shtml);
	*/
		$http({
			method: 'GET',
			url: 'https://fcipwidgetservice-dev.cfappstdcnpz1.ebiz.verizon.com/FCIPWidget/getContentByKey?key=FCIP_NGROUTE_DASHBOARDLIST'
		}).success(function(response){	
			var shtml = response;			
			jQuery('.dashboardListController').html(shtml);
			var element = jQuery('.dashboardListController');
			$compile(element.contents())($scope);
			$scope.template =  response;						
			$rootScope.navpagname = "Home";
			$rootScope.navpagnameURL = "#";
			$rootScope.pagenameURL = "#/dashboardList/" + $routeParams.menu + "/" + $routeParams.project;	
			$rootScope.pagename = $routeParams.menu;	
			$scope.project = $routeParams.project;	
			//var siteID = ($routeParams.sitename != "FinanceCIP" ? $routeParams.sitename : "");
			if($rootScope.project !=="null"){
				$scope.progressLbl=false;
				$http({
					method: 'POST',
					url: document.getElementById('tableauSvc').value+'Tableau/getThumbnail',
					headers: {'Content-Type':'application/json'},
					data: {"userName" : uVZID} 
				}).success(function(response){	
					var respData = response;						
					var thumbNailList=[];			
					for (var i=0;i<	response.workbookThumbnail.length;i++) {													
						var wb = respData.workbookThumbnail[i];				
						var tb = new ThumbnailViewModel(wb,respData.token,$http);
						thumbNailList.push(tb);				
					}			
					$scope.thumbNails = thumbNailList;				
					$scope.progressLbl=false;
					/*for (var i=0;i<	respData.workbookThumbnail.length;i++) {				
						getBase64Img(respData.workbookThumbnail[i].workbookId,respData.workbookThumbnail[i].url,respData.token);
					}*/
					
				}).error(function(response){
					$scope.progressLbl=false;
				});
			}			
		}).error(function(response){						
			
		});	
	}
	/*$http.get('https://fcipwidgetservice-dev.cfappstdcnpz1.ebiz.verizon.com/FCIPWidget/getContentByKey?key=FCIP_NGROUTE_DASHBOARDLIST').then(function(payload){ return payload });	*/	
	
	
);//End main controller

	

function getBase64Img_old(workbookid, preview, token){
	var retURL = "";
	var oReq = new XMLHttpRequest();
	oReq.open("GET", preview, true);
	oReq.setRequestHeader("X-Tableau-Auth", token);
	// use multiple setRequestHeader calls to set multiple values
	oReq.responseType = "arraybuffer";
	oReq.onload = function (oEvent) {
	  var arrayBuffer = oReq.response; // Note: not oReq.responseText
	  if (arrayBuffer) {
		var u8 = new Uint8Array(arrayBuffer);
		var b64encoded = btoa(String.fromCharCode.apply(null, u8));
		var mimetype="image/png"; // or whatever your image mime type is		
		if (document.getElementById('img_' +workbookid) != null) {
			document.getElementById('img_' +workbookid).src = "data:"+mimetype+";base64,"+b64encoded;						
		}
	  }
	};
	oReq.send(null);	
	return retURL;
}
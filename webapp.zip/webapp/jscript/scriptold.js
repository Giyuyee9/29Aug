// script.js - Client side Controller Script 

var config = {
	host: window.location.hostname,	
	port: window.location.port,
	isSecure: window.location.protocol === "https:"
};

var qlikAPI = (config.isSecure ? "https://" : "http://" ) + config.host + (config.port ? ":" + config.port : "" );

var actasadmin=false;  // Default act as admin should always be false.
var restWebserviceHost;
var currentlyLoginUser;
var restWebserviceHostlookup;
var restWebserviceHostapp;
var restWebserviceHostrep;
var fcipUIHost;
var refresh;
var isTableauSecure;
var fcipApp = angular.module('fcipApp', [ 'ngRoute' ]);

var wgserver = 'tbwtpc04advvg.tdc.vzwcorp.com';
var uVZID ="v762648"; 
var viz;
var tabkeyApi="http://eu9sacexn02.ebiz.verizon.com:7002/analyticsTableauKey/TableauKey"; 
var sitename="CPM"; 

fcipApp.config(function($routeProvider) {
	$routeProvider

	.when('/', {
		templateUrl : 'pages/home.html',
		controller : 'uarController'
	})

	.when('/tool', {
		templateUrl : 'pages/tools.html',
		controller : 'uarController'
	})
	
	.when('/dashboardList/:menu/:project/:sitename', {
		templateUrl : 'pages/dashboardList.html',
		controller : 'dashboardListController'
	})
	
	.when('/tableau/:menu/:site/:viewname', {
		templateUrl : 'pages/tableau.html',
		controller : 'tableauController'
	})

	.when('/applications', {
		templateUrl : 'pages/manageApplication.html',
		controller  : 'applicationsController'
	})

	.when('/tab1', {
		templateUrl : 'pages/accessreviewreports.html',
		controller : 'reportController'
	})

	.when('/tab2', {
		templateUrl : 'pages/accessreviewreports.html',
		controller : 'reportController'
	})
	
	.when('/adminpage', {
		templateUrl : 'pages/uar.html',
		controller : 'uarController'
	})
	
	.when('/userpage', {
		templateUrl : 'pages/uar.html',
		controller : 'uarController'
	})

});



//Default call goes to mainController
fcipApp.controller('mainController',function($scope,$rootScope,$http) {	
		
	$scope.expandedAll=true;
	$scope.adminLbl=false;
	$scope.userLbl=true;
	$scope.mydisabled=false;  //Admin user toggle
	$scope.progressLbl=true;
	$rootScope.navpagname = "Home";
	$rootScope.navpagnameURL = "#";
	$rootScope.pagename="";
	$rootScope.pagenameURL = "";
	
	
	$scope.singoutFn = function(){
		var promise = $http.get(fcipUIHost+'logout');
		promise.then(function(payload){		
		currentlyLoginUser=null;
	    document.getElementById("ara_txn_eid_hidden").value = null;
	    window.location.assign("Logout.html");
	    alert("You've been logged out successfully");
		});
	}
	
	$scope.actAsAdminFn = function(){
		actasadmin = true;
		$scope.adminLbl=true;
		$scope.userLbl=false;
		alert("Now you have the admin privileges!");
		$scope.$broadcast("REFRESH");
	}
	
	$scope.actAsUserFn= function(){
		actasadmin = false;
		$scope.adminLbl=false;
		$scope.userLbl=true;
		alert("Admin privileges released!");
		$scope.$broadcast("REFRESH");
	}		
	currentlyLoginUser=document.getElementById("ara_txn_eid_hidden").value;
	restWebserviceHostlookup=document.getElementById("ara_ldap_host_hidden").value;	
	fcipUIHost=document.getElementById("ara_ui_host_hidden").value;
	wgserver=document.getElementById("tableauServer").value;
	tabkeyApi=document.getElementById("tableauKeyApi").value;
	sitename=document.getElementById("tableauSite").value;
	isTableauSecure=document.getElementById("tableauSECURE").value;
	
/*Test Data	*/
	/*restWebserviceHost="https://fciparatxnws-dev.cfappstpanpz1.ebiz.verizon.com/";
	currentlyLoginUser="3590639062";
	restWebserviceHostlookup="https://fciparaldapws-dev.cfappstpanpz1.ebiz.verizon.com/";
	restWebserviceHostapp="https://fcipfcipAppws-dev.cfappstpanpz1.ebiz.verizon.com/";
	restWebserviceHostrep="https://fcipararepws-sit.cfappstpanpz1.ebiz.verizon.com/";*/
	
	if(restWebserviceHost==="null"){
		alert("Error : Unable to read hostname(restWebserviceHost) from environment variable");
		 var uhost = prompt("Please enter HostName", "");
		    if (uhost != null) {
		    	restWebserviceHost=uhost;
		    }
	}
	$scope.initialized = false;
	if(currentlyLoginUser==="null"){				
	
			var promise = $http.get(fcipUIHost+'getEid');
			promise.then(function(payload){							
				currentlyLoginUser = '2638303915'; /* payload.data;*/
				$scope.userName=currentlyLoginUser;
				alert(currentlyLoginUser);
				var userEid = {
						"eid" :  currentlyLoginUser
					};

				$scope.progressLbl=false;	
				
				$http({
					method: 'POST',
					url: restWebserviceHostlookup+'FCIP/ARA/1.0/LDAP/getUserRole',
					headers: {'Content-Type':'application/json'},
					data: userEid 
				}).success(function(response){				
					$scope.userDetails = response;
					$scope.progressLbl=true;
					uVZID = $scope.userDetails.userid; 
					$scope.initialized = true;
				}).error(function(response){
					$scope.ResponseDetails = "GetUserRole call -Error:"+response;
					$scope.progressLbl=true;
				});				
				
				
				
			});	
    	
	}

	if(restWebserviceHostlookup==="null"){
		alert("Error : Unable to read hostname(restWebserviceHostlookup) from environment variable");
		 var uhost = prompt("Please enter HostName", "");
		    if (uhost != null) {
		    	restWebserviceHostlookup=uhost;
		    }
	}
	
	if(restWebserviceHostapp==="null"){
		alert("Error : Unable to read hostname(restWebserviceHostapp) from environment variable");
		 var uhost = prompt("Please enter HostName", "");
		    if (uhost != null) {
		    	restWebserviceHostapp=uhost;
		    }
	}

	if(restWebserviceHostrep==="null"){
		alert("Error : Unable to read hostname(restWebserviceHostrep) from environment variable");
		 var uhost = prompt("Please enter HostName", "");
		    if (uhost != null) {
		    	restWebserviceHostrep=uhost;
		    }
	}
	/*ara_rep_host_hidden*/
	
	
});//End main controller


function initViz(tabURL) {
	var containerDiv = document.getElementById("vizContainer");
	var    url = tabURL;
	var    options = {
			hideTabs: true,
			onFirstInteractive: function () {
				console.log("Run this code when the viz has finished loading.");
			}
		};
	
	var viz = new tableau.Viz(containerDiv, url, options); 
}

function ThumbnailViewModel(workbook,token,http,sitename) {		
	
	var self = this;
	self.ModelName = "Thumbnails";				
	self.WorkBookId = workbook.workbookId;
	self.WorkBookName = workbook.workbookName;
	self.ProjectId = workbook.projectId;
	self.ProjectName = workbook.projectName;
	self.SRC = getBase64Img(workbook.workbookId,workbook.url,token,http,sitename);
	self.ViewURL = getViewURL(workbook.workbookId,workbook.workbookName,http,sitename);	
}

fcipApp.controller('dashboardListController',function($scope,$rootScope,$routeParams, $http) {
	$rootScope.navpagname = "Home";
	$rootScope.navpagnameURL = "#/";
	$rootScope.pagenameURL = "#/dashboardList/" + $routeParams.menu + "/" + $routeParams.project + "/" + $routeParams.sitename;	
	$rootScope.pagename = $routeParams.menu;	
	$scope.project = $routeParams.project;	
	var siteID = ($routeParams.sitename != "FinanceCIP" ? $routeParams.sitename : "");
	if($rootScope.project !=="null"){
		$scope.progressLbl=false;
		$http({
			method: 'POST',
			url: document.getElementById('tableauSvc').value+'Tableau/getThumbnail?' + (new Date()).getTime(),
			headers: {'Content-Type':'application/json'},
			data: {"userName" : uVZID, "siteName" : siteID} 
		}).success(function(response){	
			var respData = response;						
			var thumbNailList=[];			
			for (var i=0;i<	response.workbookThumbnail.length;i++) {											
				var wb = respData.workbookThumbnail[i];		
				var wbName = wb.workbookName.toString().toUpperCase();
				if(wb.projectName == $routeParams.project){
					console.log($routeParams.sitename + " " + wbName.indexOf('SPEND'))
					if ($routeParams.sitename == 'SCA'){
						if(wbName.indexOf('SPEND')>-1){
							var tb = new ThumbnailViewModel(wb,respData.token,$http,siteID);
							thumbNailList.push(tb);			
						}
					} else {
						var tb = new ThumbnailViewModel(wb,respData.token,$http,siteID);
						thumbNailList.push(tb);				
					}
				}
			}			
			$scope.thumbNails = thumbNailList;				
			$scope.progressLbl=false;
			/*for (var i=0;i<	respData.workbookThumbnail.length;i++) {				
				getBase64Img(respData.workbookThumbnail[i].workbookId,respData.workbookThumbnail[i].url,respData.token);
			}*/
			
		}).error(function(response){
			$scope.progressLbl=false;
		});
	}
	
});//End main controller

	function getViewURL(workbookId, workbookName, http, sitename){
		
		http({
			method: 'POST',
			url: document.getElementById('tableauSvc').value+'Tableau/getViewsForWorkBook',
			headers: {'Content-Type':'application/json'},
			data: {"workbookId" : workbookId, "siteName" : sitename} 
		}).success(function(response){				
			for (var i=0;i<1;i++) {												
				if (document.getElementById('a_' +workbookId) != null && response != "" && response != null) {					
					document.getElementById('a_' +workbookId).href = "#/tableau/" + workbookName + "/" + (sitename=="" ?"FinanceCIP" : sitename) + "/" + response[i].contentUrl.split('/')[0] + '|' + response[i].contentUrl.split('/')[2];
				}
			}						
		}).error(function(response){						
			document.getElementById('a_' +workbookid).href = "";
		});
	}

	function getBase64Img(workbookid, preview, token,http, sitename){
		/*
		http({
			method: 'POST',
			url: document.getElementById('tableauSvc').value+'Tableau/getPreviewImageBase64',
			headers: {'Content-Type':'application/json'},
			data: {"url" : preview, "siteName" : sitename} 
		}).success(function(response){							
			var arrayBuffer = response;				
			var mimetype="image/png"; // or whatever your image mime type is									
			if (document.getElementById('img_' +workbookid) != null) {				
				document.getElementById('img_' +workbookid).src = "data:"+mimetype+";base64,"+response;						
			}			
		}).error(function(response){		
			alert(response);
			var arrayBuffer = response;				
			var mimetype="image/png"; // or whatever your image mime type is									
			if (document.getElementById('img_' +workbookid) != null) {				
				document.getElementById('img_' +workbookid).src = "data:"+mimetype+";base64,"+response;						
			}
		});
		*/
		
		jQuery.ajax({ 	// start 2
					url: document.getElementById('tableauSvc').value+'Tableau/getPreviewImageBase64',			
					contentType: "application/json",
					dataType : 'json',	
					type: 'post',
					cache: false,
					data : JSON.stringify({"url" : preview, "siteName" : sitename}),
					success : function(response) {					  
					  var arrayBuffer = response.responseText;				
					  var mimetype="image/png"; // or whatever your image mime type is									
					  if (document.getElementById('img_' +workbookid) != null) {				
						  document.getElementById('img_' +workbookid).src = "data:"+mimetype+";base64,"+response.responseText;						
					  }											
					},
					error : function(resp){						
						var arrayBuffer = resp.responseText;				
						var mimetype="image/png"; // or whatever your image mime type is									
						if (document.getElementById('img_' +workbookid) != null) {				
							document.getElementById('img_' +workbookid).src = "data:"+mimetype+";base64,"+resp.responseText;						
						}
					}
				});
	}

function getBase64Img_old(workbookid, preview, token){
	var retURL = "";
	var oReq = new XMLHttpRequest();
	oReq.open("GET", preview, true);
	oReq.setRequestHeader("X-Tableau-Auth", token);
	// use multiple setRequestHeader calls to set multiple values
	oReq.responseType = "arraybuffer";
	oReq.onload = function (oEvent) {
	  var arrayBuffer = oReq.response; // Note: not oReq.responseText
	  if (arrayBuffer) {
	  	
		var u8 = new Uint8Array(arrayBuffer);
		var b64encoded = btoa(String.fromCharCode.apply(null, u8));
		var mimetype="image/png"; // or whatever your image mime type is		
		if (document.getElementById('img_' +workbookid) != null) {
			document.getElementById('img_' +workbookid).src = "data:"+mimetype+";base64,"+b64encoded;						
		}
	  }
	};
	oReq.send(null);	
	return retURL;
}

fcipApp.controller('qlikController',function($scope,$rootScope,$routeParams, $http) {
	$rootScope.navpagname = "Home";
	$rootScope.navpagnameURL = "#";
	$rootScope.pagenameURL = "";	
	$rootScope.pagename = "";	
	loadTableauView('SCA','ExecutiveDiversitySpend2017|ExecutiveDiversitySpend','vizExecSpend');
	window.setTimeout(function() {loadTableauView('SCA','SourcingDirectorDiversitySpend2017|SourcingDirectorDiversitySpend','vizSpend');}, 2000);							
	
});

var viz;
//Default call goes to tableauController
fcipApp.controller('tableauController',function($scope,$rootScope,$routeParams, $http) {	
	$rootScope.navpagname = $rootScope.pagename;
	$rootScope.navpagnameURL = $rootScope.pagenameURL;	
	document.getElementById('a_navpagenameURL').href = $rootScope.pagenameURL;
	$rootScope.pagenameURL = "";
	$rootScope.pagename = $routeParams.menu;
	
	var tableauToken = "";
	var TableauServer = (isTableauSecure == 'Y' ? "https://" : "http://") + wgserver +"/trusted/";
	var viewName = "/views/" +  $routeParams.viewname.split('|')[0] + "/" + $routeParams.viewname.split('|')[1] + "?:embed=y&:display_count=no#5";	
	var params = "?:embed=yes&:toolbar=no&:customViews=no";			
	var Auth_URL = tabkeyApi;/*"http://eu9sacexn02.ebiz.verizon.com:7002/analyticsTableauKey/TableauKey";*/ 
	var keyURL = Auth_URL + "?username=" + uVZID + "&wgserver=" + wgserver + "&target_site=" + $routeParams.site + "&secure="+ isTableauSecure +"&Submit=Submit+Query";		
		
	getTableauKey(keyURL,TableauServer,viewName,params,'vizContainer',$routeParams.site);
	
});//End main controller

function initViz(tabURL, divTabID) {	
	if (typeof(divTabID) == 'undefined' || divTabID == null) { divTabID = 'vizContainer'}
    var containerDiv = document.getElementById(divTabID);
    var    url = tabURL;
    var    options = {
            hideTabs: false,
            onFirstInteractive: function () {
                console.log("Run this code when the viz has finished loading.");
            }
    };    
    viz = new tableau.Viz(containerDiv, url, options);
    window.setTimeout(function(){resizeViz();},1000);
    // Create a viz object and embed it in the container div.
}	

function  getTableauKey(keyURL,TableauServer,viewName,params,divTabID,sitename){
	jQuery.support.cors = true;
	jQuery.ajax({ 	// start 2
		url: keyURL,			
		dataType : 'json',	
		type: 'get',
		cache: false,
		success: function (stockInfo) {				
			tableauToken = stockInfo;	                   						
			initViz(TableauServer + tableauToken + "/t/" + sitename + viewName + params,divTabID);
		},error: function (request, textStatus, errorThrown) {				
			if(request.status=='200'){	
				var tableauToken = request.responseText;
				initViz(TableauServer + tableauToken + "/t/" + sitename + viewName + params, divTabID);
			}
		},
		complete: function (request, textStatus) {	
	
		}
	});
}


function resizeViz(){		
	
	
	/*
	var zoomLev = (screen.width/parseInt($('#vizContainer').find('iframe').css('width'))) ;
	zoomLev="0.95";
	$('#vizContainer').css('zoom',1);					
	$('#vizContainer').css('-ms-zoom',zoomLev);
	$('#vizContainer').css('-moz-transform', 'scale(' + zoomLev + ')');
	$('#vizContainer').css('-webkit-transform','scale(' + zoomLev + ')');			
	
	
	$('#vizContainer').find('iframe').css('zoom', 1);
	$('#vizContainer').find('iframe').css('-ms-zoom',zoomLev);
	$('#vizContainer').find('iframe').css('-moz-transform', 'scale(' + zoomLev + ')');
	$("#tabframe").find('iframe').css('-webkit-transform','scale(' + zoomLev + ')');							
	*/
	/*viz.setFrameSize($('#vizContainer').width()+50, $('#vizContainer').height());*/
		
}

function loadTableauView(site_name,viewname,divTabID){
	var tableauToken = "";
	var TableauServer = (isTableauSecure == 'Y' ? "https://" : "http://") + wgserver +"/trusted/";
	var viewName = "/views/" +  viewname.split('|')[0] + "/" + viewname.split('|')[1] + "?:embed=y&:display_count=no#5";	
	var params = "?:embed=yes&:toolbar=no&:customViews=no";			
	var Auth_URL = tabkeyApi;
	var keyURL = Auth_URL + "?username=" + uVZID + "&wgserver=" + wgserver + "&target_site=" + site_name + "&secure="+ isTableauSecure +"&Submit=Submit+Query";		
	
	
	getTableauKey(keyURL,TableauServer,viewName,params,divTabID,site_name);
}


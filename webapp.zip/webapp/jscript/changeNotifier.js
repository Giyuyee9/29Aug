'use strict';

fcipApp.directive('changeNotify', ['$timeout', '$animate', function($timeout, $animate) {
  return {
    link : function(scope, element, attrs) {
      attrs.$observe('changeNotify', function (val) {
        var animateClass;
        if (val.split(' ')[1] == 'dynamic') animateClass = 'highlightDyn';
        else animateClass = 'highlight';

        $animate.addClass(element, animateClass).then(function() {
          $timeout(function() {$animate.removeClass(element, animateClass);});
        });
      });
    }
  };
}]);

'use strict';	

fcipApp.filter('searchfilter', function($sce) {
    return function (input, query) {
        return $sce.trustAsHtml(input.replace(RegExp('('+ query + ')', 'gi'), '<span class="thick">$1</span>'));           
    }
});
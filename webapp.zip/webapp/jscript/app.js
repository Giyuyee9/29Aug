// script.js - Client side Controller Script 
var actasadmin=false;  // Default act as admin should always be false.
var restWebserviceHost;
var currentlyLoginUser;
var restWebserviceHostlookup;
var restWebserviceHostapp;
var restWebserviceHostrep;
var isTableauSecure;
var restAppSvc; var appId;
var fcipUIHost;
var refresh;

var spendApp  = angular.module('spendApp', [ 'ngRoute' ]);


var wgserver = 'tbwtpc04advvg.tdc.vzwcorp.com';
var uVZID ="v762648"; 
var viz;
var tabkeyApi="http://eu9sacexn02.ebiz.verizon.com:7002/analyticsTableauKey/TableauKey"; 
var sitename="CPM"; 

var $routeProviderReference; routes=[];

fcipApp.config(function ($routeProvider) {
    $routeProviderReference = $routeProvider;
});

fcipApp.run(['$route', '$http', '$rootScope',
function ($route, $http, $rootScope) {
    $http.get("jscript/routes/routedata.json").success(function (data) {    	
        var iLoop = 0, currentRoute;
        routes = data.records;
        for (iLoop = 0; iLoop < data.records.length; iLoop++) {
            currentRoute = data.records[iLoop];    
            var routeTemplate = '';                        
            var routeName = currentRoute.ROUTE_URL;
            var routeType = currentRoute.ROUTE_TYPE;
            if (routeType.toUpperCase() == 'IFRAME'){
            	routeTemplate = '<iframe id="ifrNTSummary" width="100%" height="1024px"  style="overflow: hidden; width: 100%;height:1024px" src="' + currentRoute.ROUTE_PAGEURL + '" onload="resizeIframe(this)"></iframe>';
            }
            if (typeof(currentRoute.ROUTE_CONTROLLER_FILE) != 'undefined' && currentRoute.ROUTE_CONTROLLER_FILE != null && currentRoute.ROUTE_CONTROLLER_FILE != ""){
            	loadDynScript('scr_' + currentRoute.ROUTE_NAME,currentRoute.ROUTE_CONTROLLER_FILE);
            }
            $routeProviderReference.when(routeName, {         
            	templateHTML : routeTemplate, 
            	templateUrl: (typeof(currentRoute.ROUTE_PAGEURL) == 'undefined' ? '': currentRoute.ROUTE_PAGEURL) ,
				controller : (typeof(currentRoute.ROUTE_CONTROLLER) == 'undefined' ? '': currentRoute.ROUTE_CONTROLLER),
				resolve: {
					param: function($http,$q,$route,$routeParams)
					{	
						if($route.current.$$route.templateHTML != ""){
							$route.current.$$route.template = $route.current.$$route.templateHTML; 
						}
						/*
						var currentRoute;
						for (iLoop = 0; iLoop < routes.length; iLoop++) {
							currentRoute = routes[iLoop];
							console.log($route.current.$$route.originalPath);								
						}
						*/
						
						return currentRoute.resolve;
					}
				}
            });
        }
        $route.reload();
    });
}]);

function loadDynScript(scriptId,URL){	
    // Check for existing script element and delete it if it exists
    var js = document.getElementById(scriptId);
    if(js !== null) {
        document.body.removeChild(js);
        console.info("---------- Script refreshed ----------");
    }

    // Create new script element and load a script into it
    js = document.createElement("script");
    js.src = URL;
    js.id = scriptId;
    document.body.appendChild(js);    
}

/*
fcipApp.config(function($routeProvider) {
	
	$routeProvider
	.when('/', {
		templateUrl : 'pages/home.html'
	})

	.when('/tool', {
		templateUrl : 'pages/tools.html'
	})
	
	.when('/ar', {
		template : '<iframe id="ifrSpend" width="100%" style="overflow: hidden; width: 100%;" src="https://fcipqliktest.ebiz.verizon.com/extensions/spenddashboard/spenddashboard.html" onload="resizeIframe(this)"></iframe>',
		controller : 'iframeController'	
	})
	
	.when('/ntsummary', {
		template : '<iframe id="ifrNTSummary" width="100%"  style="overflow: hidden; width: 100%;" src="https://fcipqliktest.ebiz.verizon.com/extensions/apptest/apptest.html" onload="resizeIframe(this)"></iframe>',
		controller : 'iframeController'		
	})
	
	.when('/dashboardList/:menu/:project/:sitename', {
		templateUrl : 'pages/dashboardList.html' //,controller : 'dashboardListController'
	})
	
	.when('/dashboardListNew/:menu/:project/:sitename', {	
		templateURI : 'https://fcipwidgetservice-dev.cfappstdcnpz1.ebiz.verizon.com/FCIPWidget/getContentByKey?key=FCIP_NGROUTE_DASHBOARDLIST',
		controllerURI : 'https://fcipwidgetservice-dev.cfappstdcnpz1.ebiz.verizon.com/FCIPWidget/getContentByKey?key=FCIP_NGROUTE_CTRLR_DASHBOARDLIST',
		controllerName : 'dashboardListController',		
		template: '',
		resolve : {
			templateLoad : function($http,$q,$route,$routeParams) {						
				var defer = $q.defer();
				//setRouteTemplate($http,defer,$route,$route.current.$$route.templateURI);				
				$route.current.$$route.template = $http.get($route.current.$$route.templateURI).then(function(response){
							 return '<div class="container dashboardListController" ng-app="fcipApp" ng-controller="dashboardListController">' + response.data + '</div>';
							defer.resolve();
						});
				defer.promise;		
			}
		}	
	})
	
	.when('/tableau/:menu/:site/:viewname', {
		templateUrl : 'pages/tableau.html',
		controller : 'tableauController'
	})	

});
*/

function setRouteTemplate(http,q,route,URL){	
	http({
		method: 'GET',
		url: URL
	}).success(function(response, status, headers, config){				
		route.current.$$route.template = '<div class="container dashboardListController" ng-app="fcipApp" ng-controller="dashboardListController">' + response.data + '</div>';		
		q.resolve(response, status, headers, config);				
	});	
	return q.promise;	
}


function loadTemplate(http,URL){		
	http({
			method: 'GET',
			url: URL
		}).success(function(response){				
			return response;						
		}).error(function(response){						
			
		});	
	}

fcipApp.controller('iframeController',function($scope,$rootScope, $route, $routeParams, $http) {	
	$scope.scope_src = 'https://fcipqliktest.ebiz.verizon.com/extensions/spenddashboard/spenddashboard.html';	
});	

fcipApp.controller('dynamicController',function($scope,$rootScope,$routeParams, $http) {	
	$http.get('https://fcipwidgetservice-dev.cfappstdcnpz1.ebiz.verizon.com/FCIPWidget/getContentByKey?key=FCIP_NGROUTE_DASHBOARDLIST').then(function(payload){ $scope.template = payload });	
});	




// script.js - Client side Controller Script
var actasadmin=false;  // Default act as admin should always be false.
var restWebserviceHost;
var currentlyLoginUser;
var restWebserviceHostlookup;
var restWebserviceHostapp;
var restWebserviceHostrep;
var isTableauSecure;
var restAppSvc; var appId;
var fcipUIHost;
var refresh;
var classuiSvc=''; 

var fcipApp  = angular.module('fcipApp', [  'ngAnimate','ngRoute','ui.bootstrap','infinite-scroll','hljs' ]);

var wgserver = 'tbwtpc04advvg.tdc.vzwcorp.com';
var uVZID ="v762648";
var viz;
var tabkeyApi="http://eu9sacexn02.ebiz.verizon.com:7002/analyticsTableauKey/TableauKey";
var sitename="CPM";

fcipApp.config(function($routeProvider, $provide, $compileProvider, $controllerProvider) {
  fcipApp._controller = fcipApp.controller;
  fcipApp._service = fcipApp.service;
  fcipApp._factory = fcipApp.factory;
  fcipApp._directive = fcipApp.directive;
  fcipApp._constant = fcipApp.constant;

  fcipApp.controller = function(name, cons) {
    $controllerProvider.register(name, cons);
    return (this);
  };

  fcipApp.service = function(name, cons) {
    $provide.service(name, cons);
    return (this);
  };

  fcipApp.factory = function(name, cons) {
    $provide.factory(name, cons);
    return (this);
  };

  fcipApp.directive = function(name, cons) {
    $compileProvider.directive(name, cons);
    return (this);
  }

  fcipApp.constant = function(name, cons) {
    $provide.constant(name, cons);
    return (this);
  }

  fcipApp.findController = function(name){
    var values = fcipApp._invokeQueue;
      /*angular.forEach(values, function(value, key) {
          if(value[0] == '$controllerProvider'){
              var controllerName = value[2][0];
              console.log(value[2][0]);
              if(controllerName == name){
                return true;
              };
              //return jQuery.inArray( name, controllerList );
          }
      });*/
      var controllerList = fcipApp._invokeQueue.filter(function(el){
        return el[0] === "$controllerProvider";
      }).map(function(el){
        return el[2]["0"];
      });
      return jQuery.inArray( name, controllerList );
  }



	$routeProvider
	.when('/', {
		templateUrl : 'pages/home.html'
	})

	.when('/tool', {
		templateUrl : 'pages/tools.html'
	})

	.when('/manual', {
		templateUrl : 'pages/manual.html'
	})

  .when('/manualClassify', {
    templateUrl : 'pages/classify.html'
  })

  .when('/businessrules', {
		templateUrl : 'pages/businessrules.html'
	})

  .when('/addbusinessrule', {
		templateUrl : 'pages/addbusinessrules.html'
	})

  .when('/businessrules/:ruleid', {
		templateUrl : 'pages/editbusinessrules.html'
	})

  .when('/taxonomy', {
    templateUrl : 'pages/taxonomy.html'
  })

  .when('/accordion', {
    templateUrl : 'pages/accordion.html'
  })

	.when('/ar', {
		template : '<iframe id="ifrSpend" width="100%" style="overflow: hidden; width: 100%;" src="https://fcipqliktest.ebiz.verizon.com/extensions/spenddashboard/spenddashboard.html" onload="resizeIframe(this)"></iframe>',
		controller : 'iframeController'
	})

	.when('/ntsummary', {
		template : '<iframe id="ifrNTSummary" width="100%"  style="overflow: hidden; width: 100%;" src="https://fcipqliktest.ebiz.verizon.com/extensions/apptest/apptest.html" onload="resizeIframe(this)"></iframe>',
		controller : 'iframeController'
	})

	.when('/dashboardList/:menu/:project/:sitename', {
		templateUrl : 'pages/dashboardList.html'/*,
		controller : 'dashboardListController'*/
	})

	.when('/dashboardListNew/:menu/:project/:sitename', {
		templateURI : 'https://fcipwidgetservice-dev.cfappstdcnpz1.ebiz.verizon.com/FCIPWidget/getContentByKey?key=FCIP_NGROUTE_DASHBOARDLIST',
		controllerURI : 'https://fcipwidgetservice-dev.cfappstdcnpz1.ebiz.verizon.com/FCIPWidget/getContentByKey?key=FCIP_NGROUTE_CTRLR_DASHBOARDLIST',
		controllerName : 'dashboardListController',
		template: '',
		resolve : {
			templateLoad : function($http,$q,$route,$routeParams) {
				var defer = $q.defer();
				//setRouteTemplate($http,defer,$route,$route.current.$$route.templateURI);
				$route.current.$$route.template = $http.get($route.current.$$route.templateURI).then(function(response){
							 return '<div class="container dashboardListController" ng-app="fcipApp" ng-controller="dashboardListController">' + response.data + '</div>';
							defer.resolve();
						});
				defer.promise;
			}
		}
	})

	.when('/tableau/:menu/:site/:viewname', {
		templateUrl : 'pages/tableau.html',
		controller : 'tableauController'
	})

});


function setRouteTemplate(http,q,route,URL){
	http({
		method: 'GET',
		url: URL
	}).success(function(response, status, headers, config){
		route.current.$$route.template = '<div class="container dashboardListController" ng-app="fcipApp" ng-controller="dashboardListController">' + response.data + '</div>';
		q.resolve(response, status, headers, config);
	});
	return q.promise;
}


function loadTemplate(http,URL){
	http({
			method: 'GET',
			url: URL
		}).success(function(response){
			return response;
		}).error(function(response){

		});
	}



  fcipApp.directive('dynamicCtrl', ['$compile','$controller', '$parse',function($compile, $controller, $parse) {
    var checkAndassignController= function (elem,compile,scope,name){
          if(!fcipApp.findController(name)){
              window.setTimeout(function(elem,compile,scope,name){checkAndassignController(elem,compile,scope,name)},300);
          } else {
            assignController(elem,compile,scope,name);
          }

    };

    var assignController =function (elem,compile,scope,name) {

      elem.removeAttr('dynamic-ctrl');
      elem.attr('ng-controller', name);
      compile(elem)(scope);

    };
  return {
    restrict: 'A',
    terminal: true,
    priority: 100000,
    link: function(scope, elem) {
      var name = $parse(elem.attr('dynamic-ctrl'))(scope);
      window.setTimeout(function(){
        checkAndassignController(elem,$compile,scope,name)
      },300);
      /*
      window.setTimeout(function(){
        console.log(fcipApp.findController(name));
        elem.removeAttr('dynamic-ctrl');
        elem.attr('ng-controller', name);
        $compile(elem)(scope);
      }, 100); */
    }
  };



}]);


  function loadjscssfile(filename, filetype){

      if (filetype=="js"){ //if filename is a external JavaScript file
          var fileref=document.createElement('script')
          fileref.setAttribute("type","text/javascript")
          fileref.setAttribute("src", filename)
      }
      else if (filetype=="css"){ //if filename is an external CSS file
          var fileref=document.createElement("link")
          fileref.setAttribute("rel", "stylesheet")
          fileref.setAttribute("type", "text/css")
          fileref.setAttribute("href", filename)
      }
      if (typeof fileref!="undefined")
          document.getElementsByTagName("head")[0].appendChild(fileref)
  }

fcipApp.controller('iframeController',function($scope,$rootScope, $route, $routeParams, $http) {
	$scope.scope_src = 'https://fcipqliktest.ebiz.verizon.com/extensions/spenddashboard/spenddashboard.html';
});

fcipApp.controller('dynamicController',function($scope,$rootScope,$routeParams, $http) {
	$http.get('https://fcipwidgetservice-dev.cfappstdcnpz1.ebiz.verizon.com/FCIPWidget/getContentByKey?key=FCIP_NGROUTE_DASHBOARDLIST').then(function(payload){ $scope.template = payload });
});

var gulp = require('gulp'),
    sass = require('gulp-sass'),
    del = require('del'),
    rename = require("gulp-rename"),
    cssnano = require('gulp-cssnano'),
    notify = require('gulp-notify'),
    browserSync = require('browser-sync').create();
    //autoprefixer = require('gulp-autoprefixer'),
    //jshint = require('gulp-jshint'),
    //uglify = require('gulp-uglify'),
    //imagemin = require('gulp-imagemin'),
    //concat = require('gulp-concat'),
    //cache = require('gulp-cache'),

gulp.task('build', ['clean'], function() {
    gulp.start('copy-static-files', 'build-styles', 'build-scripts', 'watch');
});

// Delete distribution directory before rebuilding the files
gulp.task('clean', function() {
    return del(['dist']);
});

// Copy dependencies and required files to dist
gulp.task('copy-static-files', function() {
    return gulp.src([
            //'src/examples/**/*',
            'src/*.html',
            // VZBootstrap dependencies
            'src/vendor/vzbootstrap/fonts/**/*', 
            'src/vendor/vzbootstrap/styles/**/*', 
            'src/vendor/vzbootstrap/favicon.ico',
            'src/vendor/vzgui-service-angular/**/*'
          ],{ base: 'src'})

      .pipe(gulp.dest('dist'))
      .pipe(browserSync.reload({
        stream: true
      }))
});


// Compile SASS files to output CSS file in distribution directory
gulp.task('build-styles', function(){
    return gulp.src('src/assets/styles/sass/**/*.scss')
    .pipe(sass())
    .pipe(rename('vzbsangular-styles.css'))
    .pipe(gulp.dest('dist/assets/styles/'))
    .on('error', function (err) {
        gutil.log(err);
        this.emit('end');
    })
    .pipe(rename({suffix: '.min'}))
    .pipe(cssnano())
    .pipe(gulp.dest('dist/assets/styles'))
    .pipe(notify({ message: 'Styles build completed successfully' }))
    .pipe(browserSync.reload({
      stream: true
    }))
});

// Gulp JS tasks
gulp.task('build-scripts', function(){
    // TODO 
});

// Watch for file changes
gulp.task('watch', ['browserSync'], function() {
  // Watch .scss files
  gulp.watch('src/assets/styles/sass/**/*.scss', ['build-styles'], browserSync.reload);
  gulp.watch('src/examples/**/*', ['copy-static-files'], browserSync.reload);
  gulp.watch('src/vendor/**/*', ['copy-static-files'], browserSync.reload);
  gulp.watch('src/*.html', ['copy-static-files'], browserSync.reload);
});

// Serve and spin the server
gulp.task('browserSync', function() {
  browserSync.init({
    online: false,
    server: {
      baseDir: ''
    },
    //browser: ["chrome"],
    startPath: "src/examples/index.html"
  })
})
(function () {

 	var app= angular.module('vzApp');
 	app.controller('selectListCtrl', function ($scope, $log) {
 		$scope.buttonLabel = 'Select Item';
 		$scope.items = [
 		'Fahim',
 		'Gopi',
 		'Rachel',
 		'Ronald',
 		'Lara',
 		'Louise',
 		'Cesar',
 		'Henry',
 		'Mike',
 		'NONE',
 		];

 		$scope.status = {
 			isopen: false
 		};

 		$scope.toggleDropdown = function($event) {
 			$event.preventDefault();
 			$event.stopPropagation();
 			$scope.status.isopen = !$scope.status.isopen;
 		};

 		$scope.selectItem = function( item ) {
 			$scope.selectedItem = item;
 			$scope.buttonLabel = item;
 		};
 	});

 }());
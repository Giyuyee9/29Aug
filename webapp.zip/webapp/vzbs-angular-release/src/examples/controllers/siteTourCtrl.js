(function () {

 	var app= angular.module('vzApp');
 	app.controller('siteTourCtrl', function ($scope) {
 			
		
    $scope.IntroOptions = {
        steps:[
        {
            element: '#step1',
            intro: '<b>Welcome!</b><br>Main Article Image',
            position: 'top'
        },
        {
            element: '#step2',
            intro: "Another step.",
            position: 'bottom'
        },
        {
            element: '#step3',
            intro: 'Learn More'
        }
        ],
		
        showStepNumbers: false,
        exitOnOverlayClick: true,
        exitOnEsc:true,
        nextLabel: 'Next',
        prevLabel: 'Prev',
        skipLabel: 'Exit',
        doneLabel: 'Thanks'
    };

	$scope.ShouldAutoStart = false;
		
		
 	});

 }());
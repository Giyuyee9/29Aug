(function () {

 	var app= angular.module('vzApp');
 	app.controller('collapseCtrl', function ($scope) {
 		$scope.isCollapsed = false;
 	});

 }());
(function () {
 	
 	var app= angular.module('vzApp');
 	app.controller('progressbarCtrl', function ($scope) {

 		$scope.barValues=["25","50","75","95"]
 	});

 }());
(function () {

 	var app= angular.module('vzApp');
 	app.controller('multiSelectListCtrl', function ($scope, $log) {

 		/*array of selectedItems */
 		$scope.selectedItems = [];	

 		/*default label*/
 		var buttonLabelText = 'Select Item';

 		$scope.buttonLabel = buttonLabelText;
 		$scope.items = [
	 		'Fahim',
	 		'Gopi',
	 		'Rachel',
	 		'Ronald',
	 		'Lara',
	 		'Louise',
	 		'Cesar',
	 		'Henry',
	 		'Mike',
	 		'Marie',
 		];

 		$scope.status = {
 			isopen: false
 		};

 		$scope.toggleDropdown = function($event) {
 			$event.preventDefault();
 			$event.stopPropagation();
 			$scope.status.isopen = !$scope.status.isopen;

 			console.log('here');
 		};

 		$scope.checkboxHandler = function(val,valIndex) {
			//inserts unique values
			if( $scope.selectedItems.indexOf(valIndex) == -1)
				$scope.selectedItems.push(valIndex);

			else
				$scope.selectedItems.splice($scope.selectedItems.indexOf(valIndex), 1);    				//removes from array

			//debug
			//console.log($scope.selectedItems);

			if($scope.selectedItems.length == 0 )
				$scope.buttonLabel = buttonLabelText
			
			else if ($scope.selectedItems.length == 1 )
				$scope.buttonLabel = $scope.items[$scope.selectedItems[0]]
			
			else
				$scope.buttonLabel = $scope.selectedItems.length + ' selected';
			
			//appending indexes to input value
			$scope.checkedItems = $scope.selectedItems.join();
			
		};

	});

 }());
(function () {

  var app= angular.module('vzApp');
  app.controller('popoverCtrl', function ($scope) {
  $scope.dynamicPopover = {
    title: 'Popover Title',
    content: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer nulla.',
    templateUrl: 'popoverTemplate.html',
    placement: 'auto bottom',
    trigger: 'mouseenter'
  };
  
});
}()); 
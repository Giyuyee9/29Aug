(function () {

 	var app= angular.module('vzApp');
 	app.controller('ratingCtrl', function ($scope) {

	  $scope.max = 5;

	  $scope.hoveringOver = function(value) {
		$scope.overStar = value;
	  };
 	});

 }());
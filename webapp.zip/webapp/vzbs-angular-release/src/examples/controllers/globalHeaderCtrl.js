(function () {

 	var app= angular.module('vzApp');
 	app.controller('globalHeaderCtrl', function ($scope) {
 		$scope.preview = "templates/globalui-header-service-angular.html"
 	});

 }());
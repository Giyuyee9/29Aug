(function () {

 	var app= angular.module('vzApp');
 	app.controller('tabsCtrl', function ($scope) {
 		$scope.tabs = [
 		{ title:'Tab Title A', content:'Dynamic content 1' },
 		{ title:'Tab Title B', content:'Dynamic content 2' },
 		{ title:'Tab Title C', content:'Dynamic content 3' }
 		];
 	});
 	
 }());
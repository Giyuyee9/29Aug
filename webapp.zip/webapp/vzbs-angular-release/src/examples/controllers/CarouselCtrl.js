(function () {

 	var app= angular.module('vzApp');
 	app.controller('carouselCtrl', function ($scope) {
 		$scope.myInterval = 2000;
 		$scope.slides = [ 
 		{id:'0',src:'carousel-slides/slide1.jpg', title:'Empower' , text:'Slide 1'},
 		{id:'1',src:'carousel-slides/slide2.jpg', title:'Energy' , text:'Slide 2'},
 		{id:'2',src:'carousel-slides/slide3.jpg', title:'Effort' , text:'Slide 3'},
 		{id:'3',src:'carousel-slides/slide4.jpg', title:'Collaboration' , text:'Slide 4'}
 		];
 		$scope.active = 0;
 	});

 }());
(function () {

 	var app= angular.module('vzApp');
 	app.controller('pagerCtrl', function ($scope) {
 		$scope.totalItems = 64;
		$scope.currentPage = 4;
 	});

 }());
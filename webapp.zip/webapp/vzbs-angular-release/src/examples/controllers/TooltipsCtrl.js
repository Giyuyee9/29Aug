(function () {

  var app= angular.module('vzApp');
  app.controller('tooltipsCtrl', function ($scope) {
  $scope.tooltips = [
	  { placement: 'top', tabIndex: '1', linkLabel: 'Tooltip on top', tooltipText: 'Tooltip is above' },
	  { placement: 'bottom', tabIndex: '2', linkLabel: 'Tooltip on bottom', tooltipText: 'Tooltip is below' },
	  { placement: 'left', tabIndex: '3', linkLabel: 'Tooltip on left', tooltipText: 'Tooltip is on the left' },
	  { placement: 'right', tabIndex: '4', linkLabel: 'Tooltip on right', tooltipText: 'Tooltip is on the right' },
  ];
      
});
}());  

(function () {

 	var app= angular.module('vzApp');
 	app.controller('timepickerCtrl', function ($scope) {

 		$scope.preview_text='';
 		$scope.mytime = new Date();
 		$scope.hstep = 1;
 		$scope.mstep = 1;
 		$scope.ismeridian = true;

 		$scope.toggleMode = function() {
 			$scope.ismeridian = ! $scope.ismeridian;
 		};

 		$scope.changed = function () {

 			$scope.preview_text = 'Time changed to: ' +  getCurrentTime($scope.mytime);
 		};

 		function getCurrentTime(tm) {
 			var currentTime;
 			var currentDate = new Date(tm);

 			var hour = currentDate.getHours();
 			var meridiem = hour >= 12 ? " PM" : " AM";
 			currentTime = ((hour + 11) % 12 + 1) + ":" + addZero(currentDate.getMinutes())  + meridiem;
 			return currentTime;
 		}

 		function addZero(m){
 			if(m.toString().length == 1) 
 				m = '0'+m;
 			return m;
 		}
 	});
 	
 }());
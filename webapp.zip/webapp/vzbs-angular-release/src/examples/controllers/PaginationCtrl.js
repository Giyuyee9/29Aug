(function () {

	var app= angular.module('vzApp');
	app.controller('paginationCtrl', function ($scope) {
		$scope.totalItems = 125;
		$scope.currentPage = 4;

		$scope.setPage = function (pageNo) {
			$scope.currentPage = pageNo;
		};

		$scope.pageChanged = function() {
			$scope.pageNumber = $scope.currentPage;
		};
	});

}());
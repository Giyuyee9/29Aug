(function() {

     var app = angular.module('vzApp');
     app.controller('modalsCtrl', function($scope, $uibModal) {

         $scope.items = [{
                 title: 'Paragraph 1',
                 content: 'is simply dummy text of the printing \
					  and typesetting industry. Lorem Ipsum has been the industry \
					  standard dummy text ever since the 1500s, when an unknown printer \
					  versions of Lorem Ipsum.'
             },

             {
                 title: 'Paragraph 2',
                 content: 'is simply dummy text of the printing \
					  and typesetting industry. Lorem Ipsum has been the industry \
					  standard dummy text ever since the 1500s, when an unknown printer \
					  versions of Lorem Ipsum.'
             },

             {
                 title: 'Paragraph 3',
                 content: 'is simply dummy text of the printing \
					  and typesetting industry. Lorem Ipsum has been the industry \
					  standard dummy text ever since the 1500s, when an unknown printer \
					  versions of Lorem Ipsum.'
             }
         ];

         $scope.open = function() {
             var modalInstance = $uibModal.open({
                 templateUrl: 'myModalContent.html', //refers to modal content
                 controller: 'modalInstanceCtrl', //inner controller
                 scope: $scope, //scope elements
                 ariaLabelledBy: 'modal-title',
                 ariaDescribedBy: 'modal-body',
             });

         };

     }); //first controller

     // Please note that $modalInstance represents a modal window (instance) dependency.
     // It is not the same as the $uibModal service used above.
     app.controller('modalInstanceCtrl', function($scope, $uibModalInstance) {

         $scope.ok = function() {
             $uibModalInstance.close();
         };

         $scope.cancel = function() {
             $uibModalInstance.dismiss('cancel');
         };

     }); //inner controller

 }());
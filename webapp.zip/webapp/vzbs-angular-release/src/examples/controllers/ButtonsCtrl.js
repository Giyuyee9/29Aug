(function () {

	var app= angular.module('vzApp');
	app.controller('buttonsCtrl', function ($scope) {
		$scope.buttonLabels = ["Primary","Default/Standard","Small Button","Medium Button"]
	});

}());
(function () {

 	var app= angular.module('vzApp');
 	app.controller('dataTablesCtrl', function ($scope) {
 		$scope.headers=[
	 		"First Name",
	 		"Last Name",
	 		"Username"
 		];
 		$scope.members = [
	 		{ name: 'Ronald', lastName: 'Cortez', username:'@Cortez' },
	 		{ name: 'Rachel', lastName: 'Knickmeyer', username:'@Knickmeyer' },
	 		{ name: 'Fahim', lastName: 'Mohammed', username:'@Mohammed'},
	 		{ name: 'Heedo', lastName: 'Moon', username:'@Moon'}
 		];
 	});

 }());
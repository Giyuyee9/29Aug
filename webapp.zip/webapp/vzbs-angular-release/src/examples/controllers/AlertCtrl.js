(function () {

 	var app= angular.module('vzApp');
 	app.controller('alertCtrl', function ($scope) {
 		$scope.alerts = [
 		{ type: 'danger', msg: 'An Error occured with a ', linkLabel:'Link1',linkURL:'https://vzweb2.verizon.com/' },
 		{ type: 'success', msg: 'A Success Notification with a ', linkLabel:'Link2',linkURL:'https://crowdaround.verizon.com' },
 		{ type: 'info', msg: 'A Informational message with a ', linkLabel:'Link3',linkURL:'https://edirectory.verizon.com'},
 		{ type: 'warning', msg: 'A warning message awaits you with a ', linkLabel:'Link4',linkURL:'https://aboutyou.verizon.com/'}
 		];

 		$scope.closeAlert = function(index) {
 			$scope.alerts.splice(index, 1);
 		};
 	});

 }());
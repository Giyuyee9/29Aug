var vzApp = angular.module("vzApp", ['ngAnimate', 'ui.bootstrap', 'ui.router', 'ngclipboard', 'angular-intro']);
var template_url = 'templates/';

vzApp.config(
    ["$stateProvider", "$urlRouterProvider",
        function($stateProvider, $urlRouterProvider) {

            $urlRouterProvider.otherwise("/");

            $stateProvider
                .state("alertDemo", {
                    views: {
                        'description': {
                            templateUrl: template_url + "descriptions/alerts.html"
                        },

                        'mainview': {
                            url: "alerts",
                            templateUrl: template_url + "alerts.html"
                        },

                        'codeSample': {
                            templateUrl: template_url + "code/alerts.html"
                        }
                    }
                })

            .state("dropdownDemo", {
                views: {
                    'description': {
                        templateUrl: template_url + "descriptions/select-list.html"
                    },

                    'mainview': {
                        url: "select-list",
                        templateUrl: template_url + "select-list.html"
                    },

                    'codeSample': {
                        templateUrl: template_url + "code/select-list.html"
                    }
                }
            })

            .state("multiSelectDropdownDemo", {
                views: {
                    'description': {
                        templateUrl: template_url + "descriptions/multi-select-list.html"
                    },

                    'mainview': {
                        url: "multi-select-list",
                        templateUrl: template_url + "multi-select-list.html"
                    },

                    'codeSample': {
                        templateUrl: template_url + "code/multi-select-list.html"
                    }
                }
            })

            .state("datePickerDemo", {
                views: {
                    'description': {
                        templateUrl: template_url + "descriptions/date-picker.html"
                    },

                    'mainview': {
                        url: "date-picker",
                        templateUrl: template_url + "date-picker.html"
                    },

                    'codeSample': {
                        templateUrl: template_url + "code/date-picker.html"
                    }
                }
            })


            .state("buttonsDemo", {
                views: {
                    'description': {
                        templateUrl: template_url + "descriptions/buttons.html"
                    },

                    'mainview': {
                        url: "buttons",
                        templateUrl: template_url + "buttons.html"
                    },

                    'codeSample': {
                        templateUrl: template_url + "code/buttons.html"
                    }
                }
            })

            .state("progressBarDemo", {
                views: {
                    'description': {
                        templateUrl: template_url + "descriptions/progress-Bar.html"
                    },

                    'mainview': {
                        url: "progress-bar",
                        templateUrl: template_url + "progress-Bar.html"
                    },

                    'codeSample': {
                        templateUrl: template_url + "code/progress-Bar.html"
                    }
                }
            })

            .state("paginationDemo", {
                views: {
                    'description': {
                        templateUrl: template_url + "descriptions/pagination.html"
                    },

                    'mainview': {
                        url: "pagination",
                        templateUrl: template_url + "pagination.html"
                    },

                    'codeSample': {
                        templateUrl: template_url + "code/pagination.html"
                    }
                }
            })



            .state("tabsDemo", {
                views: {
                    'description': {
                        templateUrl: template_url + "descriptions/tabs.html"
                    },

                    'mainview': {
                        url: "tabs",
                        templateUrl: template_url + "tabs.html"
                    },

                    'codeSample': {
                        templateUrl: template_url + "code/tabs.html"
                    }
                }
            })



            .state("accordionsDemo", {
                views: {
                    'description': {
                        templateUrl: template_url + "descriptions/accordions.html"
                    },

                    'mainview': {
                        url: "accordions",
                        templateUrl: template_url + "accordions.html"
                    },

                    'codeSample': {
                        templateUrl: template_url + "code/accordions.html"
                    }
                }
            })

            .state("modalsDemo", {
                views: {
                    'description': {
                        templateUrl: template_url + "descriptions/modals.html"
                    },

                    'mainview': {
                        url: "modals",
                        templateUrl: template_url + "modals.html"
                    },

                    'codeSample': {
                        templateUrl: template_url + "code/modals.html"
                    }
                }
            })

            .state("carouselDemo", {
                views: {
                    'description': {
                        templateUrl: template_url + "descriptions/carousel.html"
                    },

                    'mainview': {
                        url: "carousel",
                        templateUrl: template_url + "carousel.html"
                    },

                    'codeSample': {
                        templateUrl: template_url + "code/carousel.html"
                    }
                }
            })

            .state("typeAheadDemo", {
                views: {
                    'description': {
                        templateUrl: template_url + "descriptions/type-ahead.html"
                    },

                    'mainview': {
                        url: "type-ahead",
                        templateUrl: template_url + "type-ahead.html"
                    },

                    'codeSample': {
                        templateUrl: template_url + "code/type-ahead.html"
                    }
                }
            })

            .state("timePickerDemo", {
                views: {
                    'description': {
                        templateUrl: template_url + "descriptions/time-picker.html"
                    },

                    'mainview': {
                        url: "time-picker",
                        templateUrl: template_url + "time-picker.html"
                    },

                    'codeSample': {
                        templateUrl: template_url + "code/time-picker.html"
                    }
                }
            })

            .state("toolTipsDemo", {
                views: {
                    'description': {
                        templateUrl: template_url + "descriptions/tooltips.html"
                    },

                    'mainview': {
                        url: "tooltips",
                        templateUrl: template_url + "tooltips.html"
                    },

                    'codeSample': {
                        templateUrl: template_url + "code/tooltips.html"
                    }
                }
            })

            .state("dataTablesDemo", {
                views: {
                    'description': {
                        templateUrl: template_url + "descriptions/data-tables.html"
                    },

                    'mainview': {
                        url: "data-tables",
                        templateUrl: template_url + "data-tables.html"
                    },

                    'codeSample': {
                        templateUrl: template_url + "code/data-tables.html"
                    }
                }
            })

            .state("popoversDemo", {
                views: {
                    'description': {
                        templateUrl: template_url + "descriptions/popovers.html"
                    },

                    'mainview': {
                        url: "popovers",
                        templateUrl: template_url + "popovers.html"
                    },

                    'codeSample': {
                        templateUrl: template_url + "code/popovers.html"
                    }
                }
            })

            .state("siteTourDemo", {
                views: {
                    'description': {
                        templateUrl: template_url + "descriptions/site-tour.html"
                    },

                    'mainview': {
                        url: "site-tour",
                        templateUrl: template_url + "site-tour.html"
                    },

                    'codeSample': {
                        templateUrl: template_url + "code/site-tour.html"
                    }
                }
            })

            .state("collapseDemo", {
                views: {
                    'description': {
                        templateUrl: template_url + "descriptions/collapse.html"
                    },

                    'mainview': {
                        url: "collapse",
                        templateUrl: template_url + "collapse.html"
                    },

                    'codeSample': {
                        templateUrl: template_url + "code/collapse.html"
                    }
                }
            })

            .state("pagerDemo", {
                views: {
                    'description': {
                        templateUrl: template_url + "descriptions/pager.html"
                    },

                    'mainview': {
                        url: "pager",
                        templateUrl: template_url + "pager.html"
                    },

                    'codeSample': {
                        templateUrl: template_url + "code/pager.html"
                    }
                }
            })

            .state("ratingDemo", {
                views: {
                    'description': {
                        templateUrl: template_url + "descriptions/rating.html"
                    },

                    'mainview': {
                        url: "rating",
                        templateUrl: template_url + "rating.html"
                    },

                    'codeSample': {
                        templateUrl: template_url + "code/rating.html"
                    }
                }
            })

            .state("globalHeaderDemo", {
                views: {
                    'description': {
                        templateUrl: template_url + "descriptions/global-header.html"
                    }

                }
            })

            ;
        }
    ]);

var controllers = {};

controllers.headerCtrl = function($scope) {
    $scope.navbarCollapsed = true;
}

// binding controllers to module 'myApp'
vzApp.controller(controllers);
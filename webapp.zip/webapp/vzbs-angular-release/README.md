VZBootstrap Angular - A Verizon Boostrap Framework for AngularJS UI

CONTENTS OF THIS FILE
---------------------
 * About VZBootstrap Framework
 * Features
 * VZBootstrap Angular Installation & Implementation
 * VZBootstrap Angular Examples
 * VZBootstrap Framework Documentation

About VZBoostrap Framework
--------------------------

   VZBoostrap angular uses native AngularJS directives based on Bootstrap's markup and CSS i.e; it has NO dependency on jQuery or Bootstrap's JavaScript. VZBootstrap angular manages these dependencies via 'bower'. If your applications supports any other depenency management like gulp or npm, make sure to replace the file locations of the resources listed below accordingly. 
    
    - Required dependencies includes:

    AngularJS v1.3.0 & higher (Bower component)
    Angular UI Bootstrap v1.3.3 & higher (Bower component)
    Bootstrap CSS v3.3.4 (Already included with vzbootstrap under vendor/vzbootstrap/styles/bootstrap.min.css)
    VZBootsrap v1.0.0 & higher (Already included under vendor/vzbootstrap directory with this release)
  
    Owner : Global Technology Services - Employee UX & Mobile Solutions
    Team: 
        Knickmeyer, Rachel (Manager) - rachel.knickmeyer@one.verizon.com
        
        - Develop - 
        Fahimuddin, Mohammed (Lead) - fahimuddin.mohammed@one.verizon.com
        Ronald, Cortez (Developer) - ronald.cortez@one.verizon.com
        Crystal, Branner (Developer) - crystal.branner@one.verizon.com

Features
--------------------------
* Uses Bootstrap UI core
* Uses AngularJS
* No dependency on jQuery or bootstrap JS. 
* Classified as a Standard Application on - http://vzstandards.verizon.com/Default.aspx 
* Up-to-Date Verizon branding 
* Sass (CSS Preprocessor) support 
* Dependency management by Bower and NPM 
* Compile and build with Gulp 
* Custom Verizon font icons
* Support for glyphicons (included)
* Support for font awesome icons (included)
  

VZBootstrap Angular Installation & Implementation
-----------------------------

    Follow instructions listed on - http://vzdesign.verizon.com/vzbootstrap-angular/dist/index.html 


VZBootstrap Angular Examples
--------------------------
    - http://vzdesign.verizon.com/vzbootstrap-angular/src/examples/index.html 


VZBootstrap Framework Documentation
--------------------------
    Follow instructions listed on - http://vzdesign.verizon.com/vzbootstrap

